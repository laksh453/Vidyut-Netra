import React, { useState } from 'react';
import './App.css';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import OverviewDashboard from './pages/OverviewDashboard';
import DataUploadPage from './pages/DataUploadPage';
import MeasurementReliabilityPage from './pages/MeasurementReliabilityPage';
import AnomalyDetectionPage from './pages/AnomalyDetectionPage';
import EvidencePassportPage from './pages/EvidencePassportPage';
import InspectionPrioritizationPage from './pages/InspectionPrioritizationPage';
import InspectionFeedbackPage from './pages/InspectionFeedbackPage';
import ModelEvaluationPage from './pages/ModelEvaluationPage';
import ReportsExportsPage from './pages/ReportsExportsPage';
import SettingsAboutPage from './pages/SettingsAboutPage';

const pageTitles = {
  overview: 'Executive Revenue Assurance Dashboard',
  upload: 'Smart-Meter Telemetry Ingestion & Preprocessing',
  reliability: 'Measurement Reliability Analysis Engine (Module 3)',
  anomaly: 'AI Anomaly Detection & Behavioral Modeling (Module 4)',
  passport: 'Explainable AI Evidence Passport (Module 5)',
  prioritization: 'Reliability-Aware Inspection Prioritization (Module 6)',
  feedback: 'Verified Inspection Outcome Feedback Loop (Module 7)',
  evaluation: 'Model Evaluation & Research Benchmarking (Module 8)',
  reports: 'Executive Reports & Work Order Exports (Module 9)',
  settings: 'System Architecture & Algorithmic Settings (Module 10)'
};

export default function App() {
  const getInitialPage = () => {
    const hash = window.location.hash.replace('#', '');
    return pageTitles[hash] ? hash : 'overview';
  };

  const [activePage, setActivePage] = useState(getInitialPage);
  const [selectedConsumer, setSelectedConsumer] = useState('TG-DISCOM-0016');
  const [refreshKey, setRefreshKey] = useState(0);

  React.useEffect(() => {
    const onHashChange = () => {
      const hash = window.location.hash.replace('#', '');
      if (pageTitles[hash]) {
        setActivePage(hash);
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const handleNav = (page) => {
    window.location.hash = page;
    setActivePage(page);
  };

  const handleDataReload = () => {
    setRefreshKey(prev => prev + 1);
  };

  const renderActivePage = () => {
    switch (activePage) {
      case 'overview':
        return (
          <OverviewDashboard
            key={refreshKey}
            setActivePage={handleNav}
            setSelectedConsumer={setSelectedConsumer}
          />
        );
      case 'upload':
        return <DataUploadPage onUploadSuccess={handleDataReload} />;
      case 'reliability':
        return (
          <MeasurementReliabilityPage
            key={refreshKey}
            setActivePage={handleNav}
            setSelectedConsumer={setSelectedConsumer}
          />
        );
      case 'anomaly':
        return (
          <AnomalyDetectionPage
            key={refreshKey}
            setActivePage={handleNav}
            setSelectedConsumer={setSelectedConsumer}
          />
        );
      case 'passport':
        return (
          <EvidencePassportPage
            key={`${refreshKey}-${selectedConsumer}`}
            selectedConsumer={selectedConsumer}
            setSelectedConsumer={setSelectedConsumer}
            setActivePage={handleNav}
          />
        );
      case 'prioritization':
        return (
          <InspectionPrioritizationPage
            key={refreshKey}
            setActivePage={handleNav}
            setSelectedConsumer={setSelectedConsumer}
          />
        );
      case 'feedback':
        return (
          <InspectionFeedbackPage
            key={refreshKey}
            setActivePage={handleNav}
            setSelectedConsumer={setSelectedConsumer}
          />
        );
      case 'evaluation':
        return <ModelEvaluationPage key={refreshKey} />;
      case 'reports':
        return <ReportsExportsPage key={refreshKey} />;
      case 'settings':
        return <SettingsAboutPage key={refreshKey} />;
      default:
        return <OverviewDashboard setActivePage={handleNav} setSelectedConsumer={setSelectedConsumer} />;
    }
  };

  return (
    <div className="app-container">
      <Sidebar activePage={activePage} setActivePage={handleNav} />
      <div className="main-wrapper">
        <Header
          pageTitle={pageTitles[activePage] || 'Vidyut Netra'}
          onDataReload={handleDataReload}
          activePage={activePage}
        />
        <main className="page-content">
          {renderActivePage()}
        </main>
      </div>
    </div>
  );
}
