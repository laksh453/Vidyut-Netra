import React from 'react';

export default function MetricCard({ label, value, subtext, icon: Icon, color = '#0284c7', bg = '#e0f2fe' }) {
  return (
    <div className="metric-card">
      <div className="metric-card-header">
        <span className="metric-label">{label}</span>
        {Icon && (
          <div className="metric-icon-box" style={{ backgroundColor: bg, color: color }}>
            <Icon size={18} />
          </div>
        )}
      </div>
      <div className="metric-value">{value}</div>
      {subtext && <div className="metric-footer">{subtext}</div>}
    </div>
  );
}
