import React from 'react';
import { ShieldCheck, AlertCircle, XCircle, AlertTriangle, CheckCircle } from 'lucide-react';

export default function StatusBadge({ status, type = 'status' }) {
  if (!status) return null;

  const upper = String(status).toUpperCase();

  // Reliability status badges
  if (upper === 'SUFFICIENT') {
    return (
      <span className="badge badge-sufficient">
        <ShieldCheck size={12} />
        SUFFICIENT
      </span>
    );
  }

  if (upper === 'UNCERTAIN') {
    return (
      <span className="badge badge-uncertain">
        <AlertTriangle size={12} />
        UNCERTAIN
      </span>
    );
  }

  if (upper === 'UNRELIABLE') {
    return (
      <span className="badge badge-unreliable">
        <XCircle size={12} />
        UNRELIABLE
      </span>
    );
  }

  // Risk badges
  if (upper === 'CRITICAL') {
    return (
      <span className="badge badge-critical">
        <AlertCircle size={12} />
        CRITICAL RISK
      </span>
    );
  }

  if (upper === 'HIGH') {
    return (
      <span className="badge badge-high">
        <AlertTriangle size={12} />
        HIGH RISK
      </span>
    );
  }

  if (upper === 'MEDIUM') {
    return (
      <span className="badge badge-medium">
        MEDIUM RISK
      </span>
    );
  }

  if (upper === 'LOW') {
    return (
      <span className="badge badge-low">
        <CheckCircle size={12} />
        LOW RISK
      </span>
    );
  }

  // Action badges
  if (upper === 'THEFT_INSPECTION') {
    return (
      <span className="badge badge-critical">
        Revenue Inspection Squad
      </span>
    );
  }

  if (upper === 'METER_MAINTENANCE') {
    return (
      <span className="badge badge-uncertain">
        Meter Hardware / Telemetry
      </span>
    );
  }

  if (upper === 'DESKTOP_AUDIT') {
    return (
      <span className="badge badge-blue">
        Desktop Telemetry Audit
      </span>
    );
  }

  if (upper === 'CONFIRMED_THEFT' || upper.includes('SUSPECTED IRREGULARITY')) {
    return (
      <span className="badge badge-critical">
        <AlertCircle size={12} />
        {status}
      </span>
    );
  }

  if (upper === 'FAULTY_METER' || upper.includes('METER ISSUE')) {
    return (
      <span className="badge badge-uncertain">
        <AlertTriangle size={12} />
        {status}
      </span>
    );
  }

  if (upper === 'TECHNICAL_ISSUE' || upper.includes('TECHNICAL ISSUE')) {
    return (
      <span className="badge badge-blue">
        <AlertTriangle size={12} />
        {status}
      </span>
    );
  }

  if (upper === 'LEGITIMATE_DROP' || upper.includes('LEGITIMATE CONSUMPTION')) {
    return (
      <span className="badge badge-sufficient">
        <ShieldCheck size={12} />
        {status}
      </span>
    );
  }

  if (upper === 'INCONCLUSIVE') {
    return (
      <span className="badge" style={{ backgroundColor: '#f1f5f9', color: '#475569', border: '1px solid #cbd5e1' }}>
        INCONCLUSIVE
      </span>
    );
  }

  if (upper === 'NORMAL_FALSE_ALARM') {
    return (
      <span className="badge badge-low">
        NORMAL (FALSE ALARM)
      </span>
    );
  }

  // Generic fallback badge
  return (
    <span className="badge badge-blue">
      {status}
    </span>
  );
}
