import React from 'react';
import {
  LayoutDashboard,
  UploadCloud,
  ShieldCheck,
  ZapOff,
  FileText,
  AlertTriangle,
  ClipboardCheck,
  BarChart3,
  FileSpreadsheet,
  Settings,
  Flame,
  Radio
} from 'lucide-react';

const navItems = [
  { id: 'overview', label: 'Overview Dashboard', icon: LayoutDashboard },
  { id: 'upload', label: 'Smart-Meter Upload', icon: UploadCloud },
  { id: 'reliability', label: 'Measurement Reliability', icon: ShieldCheck, tag: 'CORE' },
  { id: 'anomaly', label: 'AI Anomaly Detection', icon: ZapOff },
  { id: 'passport', label: 'Evidence Passport', icon: FileText, tag: 'XAI' },
  { id: 'prioritization', label: 'Inspection Prioritization', icon: AlertTriangle },
  { id: 'feedback', label: 'Inspection Feedback', icon: ClipboardCheck },
  { id: 'evaluation', label: 'Model Evaluation', icon: BarChart3, tag: 'BENCH' },
  { id: 'reports', label: 'Reports & Exports', icon: FileSpreadsheet },
  { id: 'settings', label: 'Settings & Architecture', icon: Settings },
];

export default function Sidebar({ activePage, setActivePage }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="brand-badge">
          <Flame size={13} />
          TISC 2026 • CHALLENGE 12
        </div>
        <div className="brand-title">
          <Radio size={22} color="#38bdf8" />
          VIDYUT NETRA
        </div>
        <div className="brand-tagline">
          Intelligent Revenue Assurance for Electricity Distribution
        </div>
      </div>

      <nav className="sidebar-nav">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <div
              key={item.id}
              className={`nav-item ${isActive ? 'active' : ''}`}
              onClick={() => setActivePage(item.id)}
            >
              <Icon size={18} />
              <span style={{ flex: 1 }}>{item.label}</span>
              {item.tag && (
                <span
                  style={{
                    fontSize: '0.65rem',
                    padding: '2px 5px',
                    borderRadius: '4px',
                    background: isActive ? 'rgba(255,255,255,0.2)' : 'rgba(56, 189, 248, 0.15)',
                    color: isActive ? '#ffffff' : '#38bdf8',
                    fontWeight: 700
                  }}
                >
                  {item.tag}
                </span>
              )}
            </div>
          );
        })}
      </nav>

      <div className="sidebar-footer">
        <div className="discom-status">
          <div className="pulse-dot"></div>
          <span style={{ fontWeight: 600, color: '#f1f5f9' }}>TSSPDCL / TSNPDCL Live</span>
        </div>
        <div style={{ color: '#94a3b8', fontSize: '0.72rem' }}>
          Telangana State Grid Analytics Engine v1.2.0
        </div>
      </div>
    </aside>
  );
}
