import React, { useState } from 'react';
import { RefreshCw, Download, Database, CheckCircle2 } from 'lucide-react';
import { loadSampleDataset } from '../api';

export default function Header({ pageTitle, onDataReload, activePage }) {
  const [loadingSample, setLoadingSample] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  const handleQuickLoad = async () => {
    try {
      setLoadingSample(true);
      const res = await loadSampleDataset();
      if (res.data.success) {
        setToastMessage('Demonstration dataset reloaded successfully!');
        if (onDataReload) onDataReload();
        setTimeout(() => setToastMessage(null), 3500);
      }
    } catch (err) {
      alert('Error loading sample: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoadingSample(false);
    }
  };

  return (
    <header className="top-header">
      <div className="header-left">
        <h1 className="page-title">{pageTitle}</h1>
        <span className="header-badge">
          Telangana Innovation Startup Challenge 2026
        </span>
        {toastMessage && (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, color: '#059669', fontSize: '0.82rem', fontWeight: 600 }}>
            <CheckCircle2 size={16} />
            {toastMessage}
          </span>
        )}
      </div>

      <div className="header-right">
        <button
          className="btn-outline btn-sm"
          onClick={() => window.open('/api/data/download-sample', '_blank')}
          title="Download Sample Smart-Meter CSV"
        >
          <Download size={14} />
          Sample CSV
        </button>

        <button
          className="btn-primary btn-sm"
          onClick={handleQuickLoad}
          disabled={loadingSample}
          title="Reset & Load 850+ Synthetic Meter Telemetry Records"
        >
          <Database size={14} />
          {loadingSample ? 'Reloading...' : 'Load Demo Data'}
        </button>
      </div>
    </header>
  );
}
