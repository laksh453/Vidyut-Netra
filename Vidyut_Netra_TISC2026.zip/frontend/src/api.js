import axios from 'axios';

const API_BASE = '/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getHealth = () => api.get('/health');
export const getSampleMetadata = () => api.get('/data/sample');
export const loadSampleDataset = () => api.post('/data/load-sample');
export const uploadDataset = (formData, onProgress) => {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/data/upload');

    if (xhr.upload && onProgress) {
      xhr.upload.onprogress = (event) => {
        if (event.lengthComputable) {
          const percent = Math.round((event.loaded * 100) / event.total);
          onProgress(percent);
        }
      };
    }

    xhr.onload = () => {
      let responseData = {};
      try {
        responseData = JSON.parse(xhr.responseText);
      } catch (e) {
        responseData = { error: xhr.responseText || 'Invalid server response' };
      }

      if (xhr.status >= 200 && xhr.status < 300) {
        resolve({ data: responseData, status: xhr.status });
      } else {
        const error = new Error(responseData.error || `Upload failed with status ${xhr.status}`);
        error.response = { data: responseData, status: xhr.status };
        reject(error);
      }
    };

    xhr.onerror = () => {
      const error = new Error('Network error during file upload. Please verify the backend server is reachable.');
      reject(error);
    };

    xhr.ontimeout = () => {
      const error = new Error('File upload timed out.');
      reject(error);
    };

    xhr.send(formData);
  });
};
export const getDataPreview = () => api.get('/data/preview');
export const getReliabilityData = (params) => api.get('/reliability', { params });
export const getConsumerReliabilityDetail = (consumerId) => api.get(`/reliability/${consumerId}`);
export const runAnomalyDetection = (params) => api.post('/anomaly/run', params);
export const getAnomalyResults = (params) => api.get('/anomaly/results', { params });
export const getEvidencePassport = (consumerId) => api.get(`/passport/${consumerId}`);
export const saveFieldVerification = (data) => api.post('/passport/verify', data);
export const uploadVerificationAttachment = (formData) => axios.post('/api/passport/attachment', formData);
export const getInspections = (params) => api.get('/inspections', { params });
export const submitInspectionFeedback = (data) => api.post('/inspections/feedback', data);
export const getInspectionOutcomes = () => api.get('/inspections/outcomes');
export const getEvaluationMetrics = () => api.get('/evaluation/metrics');
export const getExecutiveSummary = () => api.get('/reports/summary');
export const getSettings = () => api.get('/settings');
export const updateSettings = (data) => api.post('/settings', data);

export default api;
