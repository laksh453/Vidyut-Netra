import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Wrench,
  Search,
  Filter,
  CheckCircle,
  Clock,
  IndianRupee,
  MapPin,
  TrendingUp,
  FileText,
  UserCheck,
  Send
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { getInspections } from '../api';

export default function InspectionPrioritizationPage({ setActivePage, setSelectedConsumer }) {
  const [tasks, setTasks] = useState([]);
  const [summary, setSummary] = useState(null);
  const [actionFilter, setActionFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [dispatchedMap, setDispatchedMap] = useState({});

  useEffect(() => {
    fetchTasks();
  }, [actionFilter]);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const params = {};
      if (actionFilter !== 'ALL') {
        params.action = actionFilter;
      }
      const res = await getInspections(params);
      setTasks(res.data.tasks || []);
      setSummary(res.data.summary || null);
    } catch (err) {
      console.error('Failed to load inspections:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDispatch = (consumerId) => {
    setDispatchedMap(prev => ({ ...prev, [consumerId]: true }));
  };

  const filteredTasks = tasks.filter(t => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.consumer_id.toLowerCase().includes(q) ||
      t.meter_id.toLowerCase().includes(q) ||
      t.transformer_id.toLowerCase().includes(q) ||
      t.consumer_category.toLowerCase().includes(q)
    );
  });

  return (
    <div>
      {/* Research Prioritization Alert */}
      <div className="research-alert">
        <TrendingUp size={20} color="#2563eb" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title">Reliability-Aware & ROI-Optimized Operational Routing</div>
          <div className="alert-desc">
            Vidyut Netra solves DISCOM field squad fatigue. By combining AI Anomaly scores with Measurement Reliability, 
            cases with <strong>UNRELIABLE telemetry are routed to Meter Hardware / NIC Maintenance squads</strong> instead of 
            revenue theft squads. High-confidence cases with <strong>SUFFICIENT reliability are prioritized based on Benefit-Cost ROI (₹ Recoverable vs ₹ Inspection Cost)</strong>.
          </div>
        </div>
      </div>

      {/* Action Routing Metric Counters */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '24px' }}>
        <div
          className="card"
          style={{
            marginBottom: 0,
            cursor: 'pointer',
            borderLeft: '4px solid #dc2626',
            background: actionFilter === 'THEFT_INSPECTION' ? '#fef2f2' : '#ffffff'
          }}
          onClick={() => setActionFilter(actionFilter === 'THEFT_INSPECTION' ? 'ALL' : 'THEFT_INSPECTION')}
        >
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#dc2626' }}>REVENUE THEFT INSPECTIONS</div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
            {summary?.theft_inspection_count || 0} Cases
          </div>
          <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
            Sufficient Evidence + High Recovery ROI
          </div>
        </div>

        <div
          className="card"
          style={{
            marginBottom: 0,
            cursor: 'pointer',
            borderLeft: '4px solid #d97706',
            background: actionFilter === 'METER_MAINTENANCE' ? '#fffbeb' : '#ffffff'
          }}
          onClick={() => setActionFilter(actionFilter === 'METER_MAINTENANCE' ? 'ALL' : 'METER_MAINTENANCE')}
        >
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#d97706' }}>HARDWARE MAINTENANCE ORDERS</div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
            {summary?.meter_maintenance_count || 0} Cases
          </div>
          <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
            Unreliable Telemetry / Defective Meter
          </div>
        </div>

        <div
          className="card"
          style={{
            marginBottom: 0,
            cursor: 'pointer',
            borderLeft: '4px solid #2563eb',
            background: actionFilter === 'DESKTOP_AUDIT' ? '#eff6ff' : '#ffffff'
          }}
          onClick={() => setActionFilter(actionFilter === 'DESKTOP_AUDIT' ? 'ALL' : 'DESKTOP_AUDIT')}
        >
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#2563eb' }}>DESKTOP TELEMETRY AUDITS</div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
            {summary?.desktop_audit_count || 0} Cases
          </div>
          <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
            Uncertain Data / Automated Re-poll
          </div>
        </div>

        <div className="card" style={{ marginBottom: 0, borderLeft: '4px solid #059669' }}>
          <div style={{ fontSize: '0.75rem', fontWeight: 700, color: '#059669' }}>ESTIMATED TOTAL RECOVERY</div>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
            ₹{(summary?.total_estimated_recoverable_value || 0).toLocaleString()}
          </div>
          <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
            Expected Recovery vs ₹{(summary?.total_inspection_cost || 0).toLocaleString()} Cost
          </div>
        </div>
      </div>

      {/* Prioritization Roster */}
      <div className="card">
        <div className="card-title">
          <span>Ranked Field Inspection Work Orders (Multi-Criteria Priority Matrix)</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 10, color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search consumer, meter, transformer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 30, fontSize: '0.8rem', width: '250px', height: '32px' }}
              />
            </div>

            <select
              className="form-select"
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              style={{ fontSize: '0.8rem', height: '32px', width: '200px' }}
            >
              <option value="ALL">All Recommended Actions</option>
              <option value="THEFT_INSPECTION">Revenue Theft Squad</option>
              <option value="METER_MAINTENANCE">Hardware Maintenance</option>
              <option value="DESKTOP_AUDIT">Desktop Audit</option>
            </select>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Consumer ID</th>
                <th>Meter ID</th>
                <th>Category</th>
                <th>Transformer Cluster</th>
                <th>Recommended Action</th>
                <th>Reliability Qualification</th>
                <th>Est. Recovery (₹)</th>
                <th>ROI Ratio</th>
                <th>Priority Score</th>
                <th>Dispatch</th>
              </tr>
            </thead>
            <tbody>
              {filteredTasks.map((t) => {
                const isDispatched = dispatchedMap[t.consumer_id];
                return (
                  <tr key={t.consumer_id}>
                    <td style={{ fontWeight: 800, color: t.priority_rank <= 3 ? '#dc2626' : '#64748b' }}>
                      #{t.priority_rank}
                    </td>
                    <td className="code-cell">{t.consumer_id}</td>
                    <td className="code-cell" style={{ color: '#475569' }}>{t.meter_id}</td>
                    <td>{t.consumer_category}</td>
                    <td style={{ fontSize: '0.8rem', color: '#64748b' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                        <MapPin size={12} />
                        {t.transformer_id}
                      </span>
                    </td>
                    <td>
                      <StatusBadge status={t.recommended_action} />
                    </td>
                    <td>
                      <StatusBadge status={t.reliability_status} />
                    </td>
                    <td style={{ fontWeight: 700, color: '#0f172a' }}>
                      ₹{t.estimated_recoverable_value.toLocaleString()}
                    </td>
                    <td>
                      <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: t.roi_ratio >= 5.0 ? '#059669' : '#d97706' }}>
                        {t.roi_ratio}x
                      </span>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 800, color: '#0284c7' }}>
                        {t.priority_score.toFixed(1)}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <button
                          className="btn-outline btn-sm"
                          onClick={() => {
                            setSelectedConsumer(t.consumer_id);
                            setActivePage('passport');
                          }}
                          title="Review Evidence Passport"
                        >
                          <FileText size={13} />
                        </button>

                        <button
                          className={isDispatched ? 'btn-secondary btn-sm' : 'btn-primary btn-sm'}
                          style={{
                            background: isDispatched ? '#ecfdf5' : undefined,
                            color: isDispatched ? '#059669' : undefined,
                            borderColor: isDispatched ? '#a7f3d0' : undefined
                          }}
                          onClick={() => handleDispatch(t.consumer_id)}
                        >
                          {isDispatched ? (
                            <>
                              <CheckCircle size={13} />
                              Dispatched
                            </>
                          ) : (
                            <>
                              <Send size={13} />
                              Dispatch
                            </>
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
