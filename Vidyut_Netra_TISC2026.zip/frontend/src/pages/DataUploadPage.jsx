import React, { useState, useEffect, useRef } from 'react';
import {
  UploadCloud,
  FileText,
  CheckCircle,
  AlertCircle,
  Download,
  Database,
  Search,
  CheckCircle2,
  AlertTriangle,
  X,
  FileCheck,
  Activity,
  Layers,
  ArrowRight
} from 'lucide-react';
import { uploadDataset, loadSampleDataset, getDataPreview } from '../api';

export default function DataUploadPage({ onUploadSuccess }) {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [loadingSample, setLoadingSample] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [previewData, setPreviewData] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [datasetName, setDatasetName] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const fileInputRef = useRef(null);
  const dragCounter = useRef(0);

  useEffect(() => {
    fetchPreview();
  }, []);

  const fetchPreview = async () => {
    try {
      const res = await getDataPreview();
      setPreviewData(res.data.records || []);
      setMetrics(res.data.metrics || null);
      setDatasetName(res.data.dataset_name || 'None');
    } catch (err) {
      console.error('Failed to load telemetry preview:', err);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes || bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
  };

  // Drag and Drop Event Handlers
  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current += 1;
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setDragOver(true);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current -= 1;
    if (dragCounter.current <= 0) {
      dragCounter.current = 0;
      setDragOver(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current = 0;
    setDragOver(false);

    const files = e.dataTransfer ? e.dataTransfer.files : null;
    if (files && files.length > 0) {
      handleFileSelected(files[0]);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelected(e.target.files[0]);
    }
    if (e.target) {
      e.target.value = '';
    }
  };

  const handleFileSelected = (file) => {
    if (!file) return;
    setErrorMessage(null);
    setSuccessMessage(null);

    // Validate format
    const lowerName = file.name.toLowerCase();
    const isCsv = lowerName.endsWith('.csv') || file.type === 'text/csv' || file.type === 'application/vnd.ms-excel';
    if (!isCsv) {
      setErrorMessage(`Invalid file format: "${file.name}". Vidyut Netra requires standard CSV (.csv) files.`);
      setSelectedFile(null);
      return;
    }

    // Set selected file with formatted size
    setSelectedFile({
      raw: file,
      name: file.name,
      size: file.size,
      formattedSize: formatFileSize(file.size),
      lastModified: new Date(file.lastModified || Date.now()).toLocaleDateString()
    });

    // Automatically trigger upload & processing
    processUpload(file);
  };

  const processUpload = async (fileToUpload) => {
    const file = fileToUpload || selectedFile?.raw;
    if (!file) {
      setErrorMessage('Please select a CSV file to upload.');
      return;
    }

    try {
      setUploading(true);
      setUploadProgress(15);
      setErrorMessage(null);
      setSuccessMessage(null);

      const formData = new FormData();
      formData.append('file', file, file.name);

      const res = await uploadDataset(formData, (percent) => {
        setUploadProgress(Math.min(percent, 95));
      });

      setUploadProgress(100);

      if (res.data && res.data.success) {
        setSuccessMessage(
          `Dataset "${res.data.filename || file.name}" (${formatFileSize(file.size)}) uploaded and validated successfully! Processed ${res.data.total_records} records across ${res.data.unique_consumers} consumers.`
        );
        if (res.data.records && res.data.records.length > 0) {
          setPreviewData(res.data.records);
        }
        if (res.data.metrics) {
          setMetrics(res.data.metrics);
        }
        if (res.data.dataset_name) {
          setDatasetName(res.data.dataset_name);
        }
        fetchPreview();
        if (onUploadSuccess) onUploadSuccess();
      } else {
        setErrorMessage(res.data?.error || 'Failed to validate smart-meter dataset.');
      }
    } catch (err) {
      const errDetail = err.response?.data?.error || err.message || 'Error uploading CSV to backend.';
      setErrorMessage(errDetail);
    } finally {
      setUploading(false);
    }
  };

  const handleLoadSample = async () => {
    try {
      setLoadingSample(true);
      setErrorMessage(null);
      setSelectedFile(null);
      const res = await loadSampleDataset();
      if (res.data.success) {
        setSuccessMessage('Synthetic Demonstration Benchmark dataset (859 records) loaded successfully into pipeline!');
        await fetchPreview();
        if (onUploadSuccess) onUploadSuccess();
      }
    } catch (err) {
      setErrorMessage(err.response?.data?.error || 'Failed to load synthetic benchmark.');
    } finally {
      setLoadingSample(false);
    }
  };

  const filteredPreview = previewData.filter(row => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      String(row.consumer_id).toLowerCase().includes(term) ||
      String(row.meter_id).toLowerCase().includes(term) ||
      String(row.consumer_category).toLowerCase().includes(term) ||
      String(row.reading_category).toLowerCase().includes(term) ||
      String(row.transformer_id).toLowerCase().includes(term)
    );
  });

  return (
    <div>
      {/* Synthetic Demonstration Notice Banner */}
      <div className="research-alert">
        <Database size={20} color="#2563eb" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title">Smart-Meter Data Ingestion & Preprocessing Engine</div>
          <div className="alert-desc">
            Upload custom smart-meter readings or run the pre-configured benchmark. Required CSV columns are: 
            <code>consumer_id</code>, <code>meter_id</code>, <code>timestamp</code>, and <code>consumption</code>. 
            Original raw readings are preserved immutably with separate reconstructed provenance tags.
          </div>
        </div>
      </div>

      {/* Upload Zone & Benchmark Loader Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '20px', marginBottom: '24px' }}>
        {/* Interactive Drag-and-Drop & Browse Card */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Upload Smart-Meter CSV Telemetry</span>
            <button
              className="btn-outline btn-sm"
              onClick={() => window.open('/api/data/download-sample', '_blank')}
            >
              <Download size={14} />
              Template CSV
            </button>
          </div>

          {/* Drag & Drop Visual Area with Native Invisible File Input */}
          <div
            style={{
              border: dragOver ? '2px dashed #0284c7' : '2px dashed #cbd5e1',
              borderRadius: '8px',
              padding: '32px 20px',
              textAlign: 'center',
              backgroundColor: dragOver ? '#f0f9ff' : '#f8fafc',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              position: 'relative',
              overflow: 'hidden'
            }}
            onDragEnter={handleDragEnter}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            {/* Native Full-Area Invisible File Input */}
            <input
              id="csv-file-input"
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv,text/csv,application/vnd.ms-excel"
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                opacity: 0,
                cursor: 'pointer',
                zIndex: 10
              }}
              title="Click or drag and drop a smart-meter CSV file here"
              aria-label="Upload Smart-Meter CSV Telemetry"
            />

            <div style={{ pointerEvents: 'none' }}>
              <UploadCloud size={42} color={dragOver ? '#0284c7' : '#64748b'} style={{ margin: '0 auto 12px auto' }} />
              
              <div style={{ fontWeight: 800, fontSize: '0.98rem', color: '#0f172a', marginBottom: 6 }}>
                {dragOver ? 'Drop CSV File Here to Upload' : 'Drag & Drop CSV File or Click to Browse'}
              </div>

              <p style={{ fontSize: '0.8rem', color: '#64748b', marginBottom: 12 }}>
                Supports standard smart-meter interval telemetry (.csv)
              </p>

              <button
                type="button"
                className="btn-primary btn-sm"
                tabIndex={-1}
              >
                Browse Files from Computer
              </button>

              <div style={{ fontSize: '0.74rem', color: '#94a3b8', marginTop: 14 }}>
                Required headers: <code>consumer_id, meter_id, timestamp, consumption</code>
              </div>
            </div>
          </div>

          {/* Selected File Details & Progress Card */}
          {selectedFile && (
            <div style={{ marginTop: 14, padding: '12px 16px', background: '#ffffff', border: '1px solid #e2e8f0', borderRadius: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: uploading ? 8 : 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <FileText size={20} color="#0284c7" />
                  <div>
                    <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a' }}>
                      {selectedFile.name}
                    </div>
                    <div style={{ fontSize: '0.74rem', color: '#64748b' }}>
                      Size: {selectedFile.formattedSize} • Format: CSV Telemetry
                    </div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  {uploading ? (
                    <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#0284c7', display: 'flex', alignItems: 'center', gap: 6 }}>
                      <Activity className="animate-spin" size={14} />
                      {uploadProgress}%
                    </span>
                  ) : (
                    <button
                      className="btn-outline btn-sm"
                      style={{ padding: '3px 8px', fontSize: '0.72rem' }}
                      onClick={(e) => {
                        e.stopPropagation();
                        processUpload(selectedFile.raw);
                      }}
                    >
                      Re-upload
                    </button>
                  )}
                </div>
              </div>

              {/* Upload Progress Bar */}
              {uploading && (
                <div style={{ width: '100%', height: 6, background: '#e2e8f0', borderRadius: 3, overflow: 'hidden', marginTop: 8 }}>
                  <div
                    style={{
                      width: `${uploadProgress}%`,
                      height: '100%',
                      background: '#0284c7',
                      transition: 'width 0.2s ease'
                    }}
                  />
                </div>
              )}
            </div>
          )}

          {/* Error Message Box */}
          {errorMessage && (
            <div style={{ marginTop: 14, padding: '12px 14px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 6, color: '#dc2626', fontSize: '0.82rem', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <AlertCircle size={18} style={{ flexShrink: 0, marginTop: 1 }} />
              <div>
                <strong>Upload Error:</strong> {errorMessage}
              </div>
            </div>
          )}

          {/* Success Message Box */}
          {successMessage && (
            <div style={{ marginTop: 14, padding: '12px 14px', background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: 6, color: '#059669', fontSize: '0.82rem', display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <CheckCircle2 size={18} style={{ flexShrink: 0, marginTop: 1 }} />
              <div>
                <strong>Success:</strong> {successMessage}
              </div>
            </div>
          )}
        </div>

        {/* Quick Demo Dataset Loader */}
        <div className="card" style={{ marginBottom: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div className="card-title">TISC 2026 Demonstration Benchmark</div>
            <p style={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.5, marginBottom: 14 }}>
              Demonstrating to the jury? Load the Telangana smart grid synthetic benchmark with 859 records across 30 consumers and 6 distribution transformers.
            </p>
            <div style={{ background: '#f8fafc', padding: '12px', borderRadius: 6, border: '1px solid #e2e8f0', fontSize: '0.76rem', color: '#334155', marginBottom: 16 }}>
              <div>• <strong>30 Consumers</strong> across 6 Distribution Transformers</div>
              <div>• <strong>30-Day Series</strong> with controlled anomalies</div>
              <div>• <strong>Telemetry Quality Artifacts</strong>: Missing slots, duplicates & sensor jitter</div>
            </div>
          </div>

          <button
            type="button"
            className="btn-primary"
            style={{ width: '100%', justifyContent: 'center' }}
            onClick={handleLoadSample}
            disabled={loadingSample || uploading}
          >
            <Database size={16} />
            {loadingSample ? 'Loading Benchmark Data...' : 'Load Synthetic Demonstration Data'}
          </button>
        </div>
      </div>

      {/* Module 2: Preprocessing Engine Validation Audit Report */}
      {metrics && (
        <div className="card">
          <div className="card-title">
            <span>Module 2: Preprocessing Engine Validation Audit</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: 500 }}>
              Active Dataset: <strong>{datasetName}</strong> • Date Range: {metrics.date_range?.start || 'N/A'} — {metrics.date_range?.end || 'N/A'}
            </span>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '12px' }}>
            <div style={{ background: '#f8fafc', padding: '12px 14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b' }}>Total Records Ingested</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a' }}>{metrics.total_records}</div>
            </div>
            <div style={{ background: '#ecfdf5', padding: '12px 14px', borderRadius: '8px', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#059669' }}>Valid Direct Readings</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#059669' }}>{metrics.valid_records}</div>
            </div>
            <div style={{ background: '#fffbeb', padding: '12px 14px', borderRadius: '8px', border: '1px solid #fde68a' }}>
              <div style={{ fontSize: '0.75rem', color: '#d97706' }}>Missing Telemetry Gaps</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#d97706' }}>{metrics.missing_records}</div>
            </div>
            <div style={{ background: '#eff6ff', padding: '12px 14px', borderRadius: '8px', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#2563eb' }}>Reconstructed (Provenance)</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#2563eb' }}>{metrics.reconstructed_records || 0}</div>
            </div>
            <div style={{ background: '#fff1f2', padding: '12px 14px', borderRadius: '8px', border: '1px solid #fecdd3' }}>
              <div style={{ fontSize: '0.75rem', color: '#e11d48' }}>Duplicate & Inconsistent</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#e11d48' }}>{(metrics.duplicate_records || 0) + (metrics.invalid_records || 0)}</div>
            </div>
          </div>
        </div>
      )}

      {/* Dataset Preview Table */}
      <div className="card">
        <div className="card-title">
          <span>Processed Telemetry Preview ({filteredPreview.length} Records Loaded with Provenance Tags)</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 10, color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search consumer, meter, category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 30, fontSize: '0.8rem', width: '250px', height: '32px' }}
              />
            </div>
          </div>
        </div>

        <div className="table-container" style={{ maxHeight: '420px', overflowY: 'auto' }}>
          {filteredPreview.length > 0 ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Consumer ID</th>
                  <th>Meter ID</th>
                  <th>Timestamp</th>
                  <th>Consumption (kWh)</th>
                  <th>Raw Telemetry</th>
                  <th>Voltage (V)</th>
                  <th>Reading Status</th>
                  <th>Provenance Notes</th>
                </tr>
              </thead>
              <tbody>
                {filteredPreview.slice(0, 100).map((row, idx) => (
                  <tr key={idx}>
                    <td className="code-cell">{row.consumer_id}</td>
                    <td className="code-cell" style={{ color: '#475569' }}>{row.meter_id}</td>
                    <td style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{row.timestamp}</td>
                    <td style={{ fontWeight: 700, color: row.consumption === null ? '#94a3b8' : '#0f172a' }}>
                      {row.consumption !== null ? `${row.consumption} kWh` : 'NULL'}
                    </td>
                    <td style={{ fontSize: '0.8rem', color: '#64748b' }}>
                      {row.raw_consumption !== null ? `${row.raw_consumption} kWh` : 'None'}
                    </td>
                    <td style={{ fontSize: '0.8rem' }}>{row.voltage} V</td>
                    <td>
                      <span
                        style={{
                          fontSize: '0.72rem',
                          fontWeight: 700,
                          padding: '2px 7px',
                          borderRadius: 4,
                          background:
                            row.reading_category === 'OBSERVED' ? '#ecfdf5' :
                            row.reading_category === 'RECONSTRUCTED' ? '#eff6ff' :
                            row.reading_category === 'MISSING' ? '#fffbeb' : '#fff1f2',
                          color:
                            row.reading_category === 'OBSERVED' ? '#059669' :
                            row.reading_category === 'RECONSTRUCTED' ? '#2563eb' :
                            row.reading_category === 'MISSING' ? '#d97706' : '#e11d48',
                        }}
                      >
                        {row.reading_category}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.75rem', color: '#64748b', maxWidth: '300px' }}>
                      {row.provenance_notes}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div style={{ padding: '36px', textAlign: 'center', color: '#94a3b8', fontSize: '0.85rem' }}>
              No records found matching your filter or no dataset has been uploaded yet.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
