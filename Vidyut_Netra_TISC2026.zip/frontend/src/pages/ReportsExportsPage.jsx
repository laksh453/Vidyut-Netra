import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Printer,
  FileText,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Building,
  TrendingDown,
  Activity
} from 'lucide-react';
import { getExecutiveSummary, getInspections, getReliabilityData } from '../api';

export default function ReportsExportsPage() {
  const [summary, setSummary] = useState(null);
  const [inspections, setInspections] = useState([]);
  const [reliability, setReliability] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReportsData();
  }, []);

  const loadReportsData = async () => {
    try {
      setLoading(true);
      const [sumRes, inspRes, relRes] = await Promise.all([
        getExecutiveSummary(),
        getInspections(),
        getReliabilityData()
      ]);
      setSummary(sumRes.data);
      setInspections(inspRes.data.tasks || []);
      setReliability(relRes.data.consumers || []);
    } catch (err) {
      console.error('Failed to load reports:', err);
    } finally {
      setLoading(false);
    }
  };

  const exportWorkOrdersCSV = () => {
    if (inspections.length === 0) return;
    const headers = ['Priority_Rank', 'Consumer_ID', 'Meter_ID', 'Category', 'Transformer', 'Recommended_Action', 'Reliability_Status', 'Estimated_Recovery_INR', 'ROI_Ratio'];
    const rows = inspections.map(t => [
      t.priority_rank,
      t.consumer_id,
      t.meter_id,
      t.consumer_category,
      t.transformer_id,
      t.recommended_action,
      t.reliability_status,
      t.estimated_recoverable_value,
      t.roi_ratio
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VidyutNetra_WorkOrders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportWorkOrdersJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(inspections, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `VidyutNetra_WorkOrders_${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const exportReliabilityAuditCSV = () => {
    if (reliability.length === 0) return;
    const headers = ['Consumer_ID', 'Meter_ID', 'Category', 'Transformer', 'Reliability_Score', 'Qualification_Status', 'Observed_Pct', 'Missing_Pct', 'Inconsistent_Pct'];
    const rows = reliability.map(r => [
      r.consumer_id,
      r.meter_id,
      r.consumer_category,
      r.transformer_id,
      r.reliability_score,
      r.qualification_status,
      r.observed_pct,
      r.missing_pct,
      r.inconsistent_pct
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VidyutNetra_ReliabilityAudit_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <Activity className="animate-spin" size={32} style={{ margin: '0 auto 12px auto', color: '#0284c7' }} />
          <div>Compiling Executive Revenue Assurance Reports...</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Export Action Strip (Hidden on Print) */}
      <div className="no-print" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px' }}>
        <div>
          <h2 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0f172a' }}>
            Official DISCOM Revenue Assurance Reports & Exports
          </h2>
          <div style={{ fontSize: '0.78rem', color: '#64748b' }}>
            Formatted for TSSPDCL / TSNPDCL Board Submissions & Field Squad Logistics
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="btn-outline btn-sm" onClick={exportWorkOrdersCSV}>
            <Download size={14} />
            Export Work Orders (CSV)
          </button>

          <button className="btn-outline btn-sm" onClick={exportReliabilityAuditCSV}>
            <Download size={14} />
            Export Reliability Audit (CSV)
          </button>

          <button className="btn-primary btn-sm" onClick={() => window.print()}>
            <Printer size={14} />
            Print Executive Briefing (PDF)
          </button>
        </div>
      </div>

      {/* Official Executive Report Sheet */}
      <div className="card" style={{ padding: '32px', border: '1px solid #cbd5e1' }}>
        {/* Document Header */}
        <div style={{ borderBottom: '2px solid #0f172a', paddingBottom: '16px', marginBottom: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ fontSize: '0.75rem', fontWeight: 800, color: '#0284c7', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 4 }}>
              TELANGANA POWER DISTRIBUTION COMPANY • REVENUE ASSURANCE DIVISION
            </div>
            <h1 style={{ fontSize: '1.45rem', fontWeight: 900, color: '#0f172a' }}>
              Monthly Revenue Leakage & Inspection Prioritization Executive Report
            </h1>
            <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: 4 }}>
              Jurisdiction: <strong>{summary?.discom_jurisdiction}</strong> • Reference Date: <strong>{summary?.report_date}</strong>
            </div>
          </div>

          <div style={{ textAlign: 'right' }}>
            <div style={{ background: '#f0f9ff', padding: '6px 12px', borderRadius: 6, border: '1px solid #bae6fd', fontSize: '0.75rem', fontWeight: 700, color: '#0369a1' }}>
              TISC 2026 • CHALLENGE 12 BENCHMARK
            </div>
          </div>
        </div>

        {/* Section 1: Executive KPI Overview */}
        <div style={{ marginBottom: '24px' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#0f172a', marginBottom: '12px' }}>
            1. Portfolio Financial & Telemetry Overview
          </h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
            <div style={{ background: '#f8fafc', padding: 12, borderRadius: 6, border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.72rem', color: '#64748b' }}>SMART METERS MONITORED</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a', marginTop: 2 }}>{summary?.total_consumers_monitored}</div>
            </div>
            <div style={{ background: '#f8fafc', padding: 12, borderRadius: 6, border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.72rem', color: '#64748b' }}>TOTAL READINGS PROCESSED</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a', marginTop: 2 }}>{summary?.total_readings_processed}</div>
            </div>
            <div style={{ background: '#fef2f2', padding: 12, borderRadius: 6, border: '1px solid #fecaca' }}>
              <div style={{ fontSize: '0.72rem', color: '#dc2626' }}>ESTIMATED REVENUE AT RISK</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#dc2626', marginTop: 2 }}>₹{summary?.total_estimated_recoverable_revenue_inr.toLocaleString()}</div>
            </div>
            <div style={{ background: '#ecfdf5', padding: 12, borderRadius: 6, border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.72rem', color: '#059669' }}>ACTUAL RECOVERED (GROUND TRUTH)</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#059669', marginTop: 2 }}>₹{summary?.actual_recovered_revenue_inr.toLocaleString()}</div>
            </div>
          </div>
        </div>

        {/* Section 2: Research Contribution & Operational Breakdown */}
        <div style={{ marginBottom: '24px' }}>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#0f172a', marginBottom: '8px' }}>
            2. Reliability Qualification & Action Allocation
          </h3>
          <p style={{ fontSize: '0.82rem', color: '#475569', lineHeight: 1.5, marginBottom: 14 }}>
            In accordance with Vidyut Netra's measurement reliability architecture, smart meter telemetry was first 
            screened for transmission dropouts and hardware faults. Only consumers meeting statistical confidence thresholds 
            were slated for anti-theft raids, while defective units were routed for technical maintenance.
          </p>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
            <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: 14 }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#dc2626' }}>THEFT INVESTIGATIONS</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
                {summary?.field_actions_summary?.theft_inspection_count || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 2 }}>
                Sufficient evidence; verified revenue recovery squad dispatched
              </div>
            </div>

            <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: 14 }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#d97706' }}>HARDWARE MAINTENANCE</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
                {summary?.field_actions_summary?.meter_maintenance_count || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 2 }}>
                Unreliable telemetry / defective meter; assigned to M&P team
              </div>
            </div>

            <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: 14 }}>
              <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#2563eb' }}>DESKTOP TELEMETRY AUDITS</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a', marginTop: 4 }}>
                {summary?.field_actions_summary?.desktop_audit_count || 0}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 2 }}>
                Uncertain quality; scheduled for automated re-polling
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Priority Roster Preview */}
        <div>
          <h3 style={{ fontSize: '0.95rem', fontWeight: 800, color: '#0f172a', marginBottom: '10px' }}>
            3. Top Prioritized Field Work Orders (First 8 Entries)
          </h3>
          <div className="table-container">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Consumer ID</th>
                  <th>Meter ID</th>
                  <th>Category</th>
                  <th>Transformer</th>
                  <th>Action</th>
                  <th>Est. Recovery</th>
                  <th>ROI</th>
                </tr>
              </thead>
              <tbody>
                {inspections.slice(0, 8).map(t => (
                  <tr key={t.consumer_id}>
                    <td style={{ fontWeight: 800 }}>#{t.priority_rank}</td>
                    <td className="code-cell">{t.consumer_id}</td>
                    <td className="code-cell" style={{ color: '#475569' }}>{t.meter_id}</td>
                    <td>{t.consumer_category}</td>
                    <td style={{ fontSize: '0.8rem' }}>{t.transformer_id}</td>
                    <td style={{ fontSize: '0.78rem', fontWeight: 700 }}>{t.recommended_action}</td>
                    <td style={{ fontWeight: 700 }}>₹{t.estimated_recoverable_value.toLocaleString()}</td>
                    <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 700 }}>{t.roi_ratio}x</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Document Footer Signatures */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '40px', marginTop: '40px', paddingTop: '20px', borderTop: '1px solid #cbd5e1', fontSize: '0.76rem', color: '#475569' }}>
          <div>
            <strong>Report Prepared By:</strong> Vidyut Netra Automated Revenue Assurance Engine v1.2.0<br />
            Certified for Telangana Innovation Startup Challenge 2026 (Challenge 12)
          </div>
          <div style={{ textAlign: 'right' }}>
            <strong>Chief General Manager (Commercial & Revenue)</strong><br />
            Telangana State Southern Power Distribution Co. Ltd.
          </div>
        </div>
      </div>
    </div>
  );
}
