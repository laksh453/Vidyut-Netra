import React, { useState, useEffect } from 'react';
import {
  ClipboardCheck,
  CheckCircle2,
  AlertTriangle,
  History,
  Send,
  PlusCircle,
  FileCheck,
  RotateCcw,
  ShieldAlert,
  HelpCircle,
  Paperclip,
  ExternalLink,
  Search,
  Filter
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { submitInspectionFeedback, getInspectionOutcomes, getInspections } from '../api';

export default function InspectionFeedbackPage({ setActivePage, setSelectedConsumer }) {
  const [outcomes, setOutcomes] = useState([]);
  const [pendingTasks, setPendingTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [successToast, setSuccessToast] = useState(null);
  const [selectedOutcomeModal, setSelectedOutcomeModal] = useState(null);
  const [filterOutcome, setFilterOutcome] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [consumerId, setConsumerId] = useState('');
  const [meterId, setMeterId] = useState('');
  const [inspectorName, setInspectorName] = useState('K. Venkat (ADE/DPE)');
  const [inspectionDate, setInspectionDate] = useState(new Date().toISOString().slice(0, 10));
  const [finalOutcome, setFinalOutcome] = useState('Suspected irregularity requiring further investigation');
  const [finding, setFinding] = useState('CONFIRMED_THEFT');
  const [tamperType, setTamperType] = useState('Direct Phase Bypass Shunt');
  const [penaltyLevied, setPenaltyLevied] = useState('25000');
  const [recoveredRevenue, setRecoveredRevenue] = useState('18500');
  const [meterReplaced, setMeterReplaced] = useState(true);
  const [notes, setNotes] = useState('Physical meter seal tampered; 4mm bypass shunt connected across terminal block.');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [outRes, inspRes] = await Promise.all([
        getInspectionOutcomes(),
        getInspections()
      ]);
      setOutcomes(outRes.data.outcomes || []);
      const tasks = inspRes.data.tasks || [];
      setPendingTasks(tasks);
      if (tasks.length > 0 && !consumerId) {
        setConsumerId(tasks[0].consumer_id);
        setMeterId(tasks[0].meter_id);
      }
    } catch (err) {
      console.error('Error loading feedback data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleConsumerChange = (cId) => {
    setConsumerId(cId);
    const match = pendingTasks.find(t => t.consumer_id === cId);
    if (match) {
      setMeterId(match.meter_id);
    }
  };

  const handleOutcomeChange = (newOutcome) => {
    setFinalOutcome(newOutcome);
    const findingMap = {
      'Confirmed technical issue': 'TECHNICAL_ISSUE',
      'Confirmed meter issue': 'FAULTY_METER',
      'Legitimate consumption variation': 'LEGITIMATE_DROP',
      'Suspected irregularity requiring further investigation': 'CONFIRMED_THEFT',
      'Inconclusive': 'INCONCLUSIVE'
    };
    setFinding(findingMap[newOutcome] || 'INCONCLUSIVE');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!consumerId) {
      alert('Please select or specify a Consumer ID.');
      return;
    }

    try {
      setSubmitting(true);
      const payload = {
        consumer_id: consumerId,
        meter_id: meterId,
        inspector_name: inspectorName,
        officer_id: inspectorName,
        inspection_date: inspectionDate,
        final_outcome: finalOutcome,
        finding: finding,
        actual_tamper_type: tamperType,
        penalty_levied: parseFloat(penaltyLevied) || 0.0,
        recovered_revenue: parseFloat(recoveredRevenue) || 0.0,
        meter_replaced: meterReplaced ? 1 : 0,
        inspector_notes: notes
      };

      const res = await submitInspectionFeedback(payload);
      if (res.data.success) {
        setSuccessToast(`Field outcome for ${consumerId} successfully logged & fed back to ML engine!`);
        await loadData();
        setTimeout(() => setSuccessToast(null), 4000);
      }
    } catch (err) {
      alert('Error recording feedback: ' + (err.response?.data?.error || err.message));
    } finally {
      setSubmitting(false);
    }
  };

  const filteredOutcomes = outcomes.filter(item => {
    const textMatch = !searchTerm || (
      String(item.consumer_id).toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(item.meter_id).toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(item.inspector_name).toLowerCase().includes(searchTerm.toLowerCase()) ||
      String(item.final_outcome || item.finding).toLowerCase().includes(searchTerm.toLowerCase())
    );
    if (!textMatch) return false;
    if (filterOutcome === 'ALL') return true;
    const itemOutcome = item.final_outcome || item.finding;
    return String(itemOutcome).toUpperCase().includes(filterOutcome.toUpperCase());
  });

  return (
    <div>
      {/* Research Feedback Loop Notice */}
      <div className="research-alert success">
        <RotateCcw size={20} color="#059669" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title" style={{ color: '#065f46' }}>
            Active Learning & Inspection Feedback Loop (Closing the ML Gap)
          </div>
          <div className="alert-desc" style={{ color: '#047857' }}>
            One of the biggest flaws in conventional utility AI is that models operate in an open loop without 
            ground truth validation. Vidyut Netra implements an <strong>Active Learning Feedback Loop</strong>: every verified field finding 
            (Technical Issues, Meter Defects, Legitimate Solar, or Suspected Irregularities) updates the persistent database and retrains supervised classifiers.
            <strong> Unverified anomalies are never automatically treated as electricity theft.</strong>
          </div>
        </div>
      </div>

      {successToast && (
        <div style={{ padding: '12px 16px', background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: 8, color: '#059669', fontSize: '0.85rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20 }}>
          <CheckCircle2 size={18} />
          {successToast}
        </div>
      )}

      {/* Main Grid: Feedback Form & Live Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '20px', marginBottom: '24px' }}>
        {/* Inspection Form */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Log Verified Field Inspection Outcome</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b' }}>DPE / M&P Squad Record</span>
          </div>

          <form onSubmit={handleSubmit}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div className="form-group">
                <label className="form-label">Target Consumer ID</label>
                <select
                  className="form-select"
                  value={consumerId}
                  onChange={(e) => handleConsumerChange(e.target.value)}
                >
                  {pendingTasks.map(t => (
                    <option key={t.consumer_id} value={t.consumer_id}>
                      {t.consumer_id} ({t.recommended_action})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Smart Meter Serial</label>
                <input
                  type="text"
                  className="form-input"
                  value={meterId}
                  onChange={(e) => setMeterId(e.target.value)}
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div className="form-group">
                <label className="form-label">Inspecting Officer Name & Wing</label>
                <input
                  type="text"
                  className="form-input"
                  value={inspectorName}
                  onChange={(e) => setInspectorName(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Inspection Date</label>
                <input
                  type="date"
                  className="form-input"
                  value={inspectionDate}
                  onChange={(e) => setInspectionDate(e.target.value)}
                />
              </div>
            </div>

            {/* Final Inspection Outcome (Requirement 8) */}
            <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 12 }}>
              <div className="form-group">
                <label className="form-label" style={{ fontWeight: 700, color: '#0f172a' }}>
                  Verified Field Outcome (Ground Truth)
                </label>
                <select
                  className="form-select"
                  value={finalOutcome}
                  onChange={(e) => handleOutcomeChange(e.target.value)}
                  style={{ fontWeight: 600 }}
                >
                  <option value="Confirmed technical issue">Confirmed technical issue</option>
                  <option value="Confirmed meter issue">Confirmed meter issue</option>
                  <option value="Legitimate consumption variation">Legitimate consumption variation</option>
                  <option value="Suspected irregularity requiring further investigation">Suspected irregularity requiring further investigation</option>
                  <option value="Inconclusive">Inconclusive</option>
                </select>
              </div>

              <div className="form-group">
                <label className="form-label">Mechanism / Root Cause</label>
                <input
                  type="text"
                  className="form-input"
                  value={tamperType}
                  onChange={(e) => setTamperType(e.target.value)}
                  placeholder="e.g. Shunt Wire, Neutral Bypass, Rooftop Solar"
                />
              </div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div className="form-group">
                <label className="form-label">Penalty Levied (₹)</label>
                <input
                  type="number"
                  className="form-input"
                  value={penaltyLevied}
                  onChange={(e) => setPenaltyLevied(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Direct Revenue Recovered (₹)</label>
                <input
                  type="number"
                  className="form-input"
                  value={recoveredRevenue}
                  onChange={(e) => setRecoveredRevenue(e.target.value)}
                />
              </div>
            </div>

            <div className="form-group" style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <input
                type="checkbox"
                id="meterReplacedCheck"
                checked={meterReplaced}
                onChange={(e) => setMeterReplaced(e.target.checked)}
                style={{ width: 16, height: 16, cursor: 'pointer' }}
              />
              <label htmlFor="meterReplacedCheck" style={{ fontSize: '0.85rem', color: '#334155', cursor: 'pointer' }}>
                Meter Replaced / Re-sealed on site by squad
              </label>
            </div>

            <div className="form-group">
              <label className="form-label">Inspector Technical Notes & Observations</label>
              <textarea
                className="form-textarea"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </div>

            <button
              type="submit"
              className="btn-primary"
              style={{ width: '100%', justifyContent: 'center' }}
              disabled={submitting}
            >
              <Send size={15} />
              {submitting ? 'Recording Outcome & Updating Model...' : 'Submit Verified Field Outcome'}
            </button>
          </form>
        </div>

        {/* Feedback Impact Metrics */}
        <div className="card" style={{ marginBottom: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div className="card-title">Supervised Feedback Impact</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 16 }}>
              <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
                <div style={{ fontSize: '0.75rem', color: '#64748b' }}>TOTAL VERIFIED INSPECTIONS RECORDED</div>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0f172a', marginTop: 2 }}>
                  {outcomes.length} Audits
                </div>
              </div>

              <div style={{ background: '#fef2f2', padding: 14, borderRadius: 8, border: '1px solid #fecaca' }}>
                <div style={{ fontSize: '0.75rem', color: '#dc2626' }}>SUSPECTED IRREGULARITIES / THEFT</div>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#dc2626', marginTop: 2 }}>
                  {outcomes.filter(o => o.finding === 'CONFIRMED_THEFT' || (o.final_outcome && o.final_outcome.includes('Suspected irregularity'))).length} Cases
                </div>
                <div style={{ fontSize: '0.72rem', color: '#7f1d1d', marginTop: 4 }}>
                  True Positive ground truth for supervised retraining
                </div>
              </div>

              <div style={{ background: '#eff6ff', padding: 14, borderRadius: 8, border: '1px solid #bfdbfe' }}>
                <div style={{ fontSize: '0.75rem', color: '#2563eb' }}>BENIGN, TECHNICAL & DEFECTIVE CASES</div>
                <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#2563eb', marginTop: 2 }}>
                  {outcomes.filter(o => o.finding !== 'CONFIRMED_THEFT' && !(o.final_outcome && o.final_outcome.includes('Suspected irregularity'))).length} Cases
                </div>
                <div style={{ fontSize: '0.72rem', color: '#1e3a8a', marginTop: 4 }}>
                  Exonerates consumers, identifies hardware faults & prevents false accusations
                </div>
              </div>
            </div>
          </div>

          <button
            className="btn-outline"
            style={{ width: '100%', justifyContent: 'center' }}
            onClick={() => setActivePage('evaluation')}
          >
            <History size={15} />
            View Model Evaluation & ROC Benchmarks
          </button>
        </div>
      </div>

      {/* Verified Inspection History Log */}
      <div className="card">
        <div className="card-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
          <span>Verified Field Inspection History Log ({filteredOutcomes.length} Records)</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            {/* Filter by outcome */}
            <select
              className="form-select"
              value={filterOutcome}
              onChange={(e) => setFilterOutcome(e.target.value)}
              style={{ fontSize: '0.78rem', height: '32px' }}
            >
              <option value="ALL">All Outcomes</option>
              <option value="IRREGULARITY">Suspected Irregularity</option>
              <option value="METER">Meter Defect / Issue</option>
              <option value="TECHNICAL">Technical Issue</option>
              <option value="LEGITIMATE">Legitimate Variation</option>
              <option value="INCONCLUSIVE">Inconclusive</option>
            </select>

            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 9, color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search consumer, officer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 28, fontSize: '0.78rem', height: '32px', width: '200px' }}
              />
            </div>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Consumer ID</th>
                <th>Meter ID</th>
                <th>Inspecting Officer</th>
                <th>Verified Final Outcome</th>
                <th>Checklist Audit</th>
                <th>Mechanism / Defect</th>
                <th>Penalty (₹)</th>
                <th>Recovered (₹)</th>
                <th>Attachment</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOutcomes.map((item) => {
                let checklistItems = [];
                if (item.checklist_results_json) {
                  try {
                    checklistItems = JSON.parse(item.checklist_results_json);
                  } catch (e) {}
                }
                const completedChecks = checklistItems.filter(c => c.status === 'PASS' || c.status === 'FAIL').length;

                return (
                  <tr key={item.id}>
                    <td style={{ fontSize: '0.8rem', whiteSpace: 'nowrap' }}>{item.inspection_date}</td>
                    <td className="code-cell">{item.consumer_id}</td>
                    <td className="code-cell" style={{ color: '#475569' }}>{item.meter_id}</td>
                    <td style={{ fontSize: '0.82rem', fontWeight: 600 }}>{item.officer_id || item.inspector_name}</td>
                    <td>
                      <StatusBadge status={item.final_outcome || item.finding} />
                    </td>
                    <td>
                      {checklistItems.length > 0 ? (
                        <button
                          type="button"
                          className="btn-outline btn-sm"
                          style={{ padding: '2px 8px', fontSize: '0.72rem' }}
                          onClick={() => setSelectedOutcomeModal(item)}
                        >
                          {completedChecks} / {checklistItems.length} Checks
                        </button>
                      ) : (
                        <span style={{ fontSize: '0.74rem', color: '#94a3b8' }}>Direct Entry</span>
                      )}
                    </td>
                    <td style={{ fontSize: '0.8rem', color: '#334155' }}>{item.actual_tamper_type || 'None'}</td>
                    <td style={{ fontWeight: 700, color: item.penalty_levied > 0 ? '#dc2626' : '#64748b' }}>
                      ₹{Number(item.penalty_levied || 0).toLocaleString()}
                    </td>
                    <td style={{ fontWeight: 700, color: item.recovered_revenue > 0 ? '#059669' : '#64748b' }}>
                      ₹{Number(item.recovered_revenue || 0).toLocaleString()}
                    </td>
                    <td>
                      {item.attachment_name ? (
                        <a
                          href={`/api/passport/attachment/${item.attachment_name}`}
                          target="_blank"
                          rel="noreferrer"
                          style={{ fontSize: '0.74rem', color: '#0284c7', display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none', fontWeight: 600 }}
                        >
                          <Paperclip size={12} />
                          Proof
                        </a>
                      ) : (
                        <span style={{ fontSize: '0.72rem', color: '#94a3b8' }}>None</span>
                      )}
                    </td>
                    <td>
                      <button
                        type="button"
                        className="btn-outline btn-sm"
                        style={{ padding: '3px 8px', fontSize: '0.72rem' }}
                        onClick={() => {
                          if (setSelectedConsumer && setActivePage) {
                            setSelectedConsumer(item.consumer_id);
                            setActivePage('passport');
                          }
                        }}
                        title="Open full Evidence Passport"
                      >
                        <ExternalLink size={12} />
                        Passport
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 6-Point SOP Verification Checklist Modal */}
      {selectedOutcomeModal && (
        <div style={{
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100vw',
          height: '100vh',
          backgroundColor: 'rgba(15, 23, 42, 0.65)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{
            background: '#ffffff',
            borderRadius: '10px',
            width: '680px',
            maxWidth: '92vw',
            maxHeight: '85vh',
            overflowY: 'auto',
            padding: '24px',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.2)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#0f172a' }}>
                  SOP 6-Point Field Audit Checklist Record
                </h3>
                <div style={{ fontSize: '0.78rem', color: '#64748b' }}>
                  Consumer: <strong>{selectedOutcomeModal.consumer_id}</strong> • Meter: <strong>{selectedOutcomeModal.meter_id}</strong>
                </div>
              </div>
              <button
                type="button"
                className="btn-outline btn-sm"
                onClick={() => setSelectedOutcomeModal(null)}
              >
                ✕ Close
              </button>
            </div>

            <div style={{ background: '#f8fafc', padding: 12, borderRadius: 6, marginBottom: 16, fontSize: '0.8rem', display: 'flex', justifyContent: 'space-between' }}>
              <div>Officer: <strong>{selectedOutcomeModal.officer_id || selectedOutcomeModal.inspector_name}</strong></div>
              <div>Date: <strong>{selectedOutcomeModal.inspection_date}</strong></div>
              <div>Final Outcome: <strong>{selectedOutcomeModal.final_outcome || selectedOutcomeModal.finding}</strong></div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {(() => {
                let items = [];
                try {
                  items = JSON.parse(selectedOutcomeModal.checklist_results_json);
                } catch (e) {}
                return items.map((chk) => (
                  <div
                    key={chk.step}
                    style={{
                      padding: '10px 14px',
                      borderRadius: 6,
                      border: '1px solid #e2e8f0',
                      background: chk.status === 'PASS' ? '#f0fdf4' : (chk.status === 'FAIL' ? '#fef2f2' : '#f8fafc')
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                      <span style={{ fontWeight: 700, fontSize: '0.82rem' }}>
                        Step {chk.step}: {chk.action}
                      </span>
                      <span style={{
                        fontSize: '0.72rem',
                        fontWeight: 800,
                        padding: '2px 6px',
                        borderRadius: 4,
                        background: chk.status === 'PASS' ? '#059669' : (chk.status === 'FAIL' ? '#dc2626' : '#64748b'),
                        color: '#ffffff'
                      }}>
                        {chk.status}
                      </span>
                    </div>
                    {chk.notes && (
                      <div style={{ fontSize: '0.75rem', color: '#334155', fontStyle: 'italic', marginTop: 4 }}>
                        Officer Note: "{chk.notes}"
                      </div>
                    )}
                    {chk.attachment_name && (
                      <div style={{ fontSize: '0.72rem', color: '#0284c7', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
                        <Paperclip size={11} /> Proof: {chk.attachment_name}
                      </div>
                    )}
                  </div>
                ));
              })()}
            </div>

            {selectedOutcomeModal.inspector_notes && (
              <div style={{ marginTop: 16, padding: 12, background: '#fffbeb', borderRadius: 6, border: '1px solid #fde68a', fontSize: '0.78rem', color: '#92400e' }}>
                <strong>Comprehensive Synopsis:</strong> {selectedOutcomeModal.inspector_notes}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
