import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Search,
  Filter,
  Info,
  CheckCircle2,
  Clock,
  Eye,
  Activity
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { getReliabilityData } from '../api';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Cell
} from 'recharts';

export default function MeasurementReliabilityPage({ setActivePage, setSelectedConsumer }) {
  const [consumers, setConsumers] = useState([]);
  const [portfolioStats, setPortfolioStats] = useState(null);
  const [selectedStatus, setSelectedStatus] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeModalConsumer, setActiveModalConsumer] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReliability();
  }, [selectedStatus]);

  const fetchReliability = async () => {
    try {
      setLoading(true);
      const params = {};
      if (selectedStatus !== 'ALL') {
        params.status = selectedStatus;
      }
      const res = await getReliabilityData(params);
      setConsumers(res.data.consumers || []);
      setPortfolioStats(res.data.portfolio_stats || null);
    } catch (err) {
      console.error('Error fetching reliability:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredConsumers = consumers.filter(c => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.consumer_id.toLowerCase().includes(q) ||
      c.meter_id.toLowerCase().includes(q) ||
      c.consumer_category.toLowerCase().includes(q) ||
      c.transformer_id.toLowerCase().includes(q)
    );
  });

  const categoryTotalsData = portfolioStats?.category_totals ? [
    { name: 'Observed', count: portfolioStats.category_totals.OBSERVED || 0, color: '#059669' },
    { name: 'Reconstructed', count: portfolioStats.category_totals.RECONSTRUCTED || 0, color: '#2563eb' },
    { name: 'Missing', count: portfolioStats.category_totals.MISSING || 0, color: '#d97706' },
    { name: 'Inconsistent', count: portfolioStats.category_totals.INCONSISTENT || 0, color: '#e11d48' },
    { name: 'Delayed', count: portfolioStats.category_totals.DELAYED || 0, color: '#64748b' }
  ] : [];

  return (
    <div>
      {/* Research Contribution Card */}
      <div className="research-alert">
        <ShieldCheck size={20} color="#2563eb" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title">Core Research Innovation: Measurement Reliability Engine</div>
          <div className="alert-desc">
            Vidyut Netra is the first revenue assurance framework to treat <strong>measurement reliability</strong> as a primary gate. 
            Smart meters frequently experience cellular dropped packets, clock drift, and sensor glitches. By categorizing telemetry into 
            5 explicit states (Observed, Missing, Reconstructed, Inconsistent, Delayed), the system ensures DISCOM squads are not 
            deployed to accuse innocent consumers whose smart meters simply dropped cellular connection.
          </div>
        </div>
      </div>

      {/* Qualification Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px', marginBottom: '24px' }}>
        {/* SUFFICIENT */}
        <div
          className="card"
          style={{
            marginBottom: 0,
            borderLeft: '4px solid #059669',
            cursor: 'pointer',
            backgroundColor: selectedStatus === 'SUFFICIENT' ? '#f0fdf4' : '#ffffff'
          }}
          onClick={() => setSelectedStatus(selectedStatus === 'SUFFICIENT' ? 'ALL' : 'SUFFICIENT')}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#059669' }}>SUFFICIENT EVIDENCE</span>
            <ShieldCheck size={18} color="#059669" />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0f172a', lineHeight: 1.1 }}>
            {portfolioStats?.sufficient_count || 0} Meters
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: 8 }}>
            Telemetry satisfies data-quality threshold (≥80% score, &lt;3% error). Eligible for theft inspection prioritization.
          </div>
        </div>

        {/* UNCERTAIN */}
        <div
          className="card"
          style={{
            marginBottom: 0,
            borderLeft: '4px solid #d97706',
            cursor: 'pointer',
            backgroundColor: selectedStatus === 'UNCERTAIN' ? '#fffbeb' : '#ffffff'
          }}
          onClick={() => setSelectedStatus(selectedStatus === 'UNCERTAIN' ? 'ALL' : 'UNCERTAIN')}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#d97706' }}>UNCERTAIN EVIDENCE</span>
            <AlertTriangle size={18} color="#d97706" />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0f172a', lineHeight: 1.1 }}>
            {portfolioStats?.uncertain_count || 0} Meters
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: 8 }}>
            Moderate telemetry quality (60-79%). Requires secondary automated polling or desktop billing audit.
          </div>
        </div>

        {/* UNRELIABLE */}
        <div
          className="card"
          style={{
            marginBottom: 0,
            borderLeft: '4px solid #e11d48',
            cursor: 'pointer',
            backgroundColor: selectedStatus === 'UNRELIABLE' ? '#fff1f2' : '#ffffff'
          }}
          onClick={() => setSelectedStatus(selectedStatus === 'UNRELIABLE' ? 'ALL' : 'UNRELIABLE')}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#e11d48' }}>UNRELIABLE EVIDENCE</span>
            <XCircle size={18} color="#e11d48" />
          </div>
          <div style={{ fontSize: '1.8rem', fontWeight: 800, color: '#0f172a', lineHeight: 1.1 }}>
            {portfolioStats?.unreliable_count || 0} Meters
          </div>
          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: 8 }}>
            Telemetry below diagnostic threshold (&lt;60%). Disqualified from theft raids; routed to meter maintenance.
          </div>
        </div>
      </div>

      {/* Telemetry Reading Category Distribution Chart */}
      <div className="card">
        <div className="card-title">
          <span>Smart-Meter Telemetry Distribution Across Portfolio (5 Classification States)</span>
          <span style={{ fontSize: '0.78rem', color: '#64748b' }}>
            Average Reliability Index: <strong>{portfolioStats?.average_reliability_score || 0}%</strong>
          </span>
        </div>
        <div style={{ height: '200px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryTotalsData} layout="vertical" margin={{ top: 10, right: 30, left: 80, bottom: 0 }}>
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} />
              <Tooltip formatter={(val) => [`${val} Readings`, 'Count']} />
              <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                {categoryTotalsData.map((entry, idx) => (
                  <Cell key={`cell-${idx}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Consumer Reliability Table */}
      <div className="card">
        <div className="card-title">
          <span>Consumer Reliability Assessment & Qualification Roster</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 10, color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search consumer, meter, transformer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 30, fontSize: '0.8rem', width: '260px', height: '32px' }}
              />
            </div>

            <select
              className="form-select"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              style={{ fontSize: '0.8rem', height: '32px', width: '150px' }}
            >
              <option value="ALL">All Qualifications</option>
              <option value="SUFFICIENT">Sufficient Only</option>
              <option value="UNCERTAIN">Uncertain Only</option>
              <option value="UNRELIABLE">Unreliable Only</option>
            </select>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Consumer ID</th>
                <th>Meter ID</th>
                <th>Category</th>
                <th>Distribution Transformer</th>
                <th>Reliability Score</th>
                <th>Observed %</th>
                <th>Missing %</th>
                <th>Inconsistent %</th>
                <th>Evidence Qualification</th>
                <th>Diagnostic Drilldown</th>
              </tr>
            </thead>
            <tbody>
              {filteredConsumers.map((c) => (
                <tr key={c.consumer_id}>
                  <td className="code-cell">{c.consumer_id}</td>
                  <td className="code-cell" style={{ color: '#475569' }}>{c.meter_id}</td>
                  <td>{c.consumer_category}</td>
                  <td style={{ fontSize: '0.8rem', color: '#64748b' }}>{c.transformer_id}</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <span style={{ fontWeight: 800, fontSize: '0.9rem', color: c.reliability_score >= 80 ? '#059669' : c.reliability_score >= 60 ? '#d97706' : '#e11d48' }}>
                        {c.reliability_score}%
                      </span>
                    </div>
                  </td>
                  <td style={{ fontSize: '0.82rem' }}>{c.observed_pct}%</td>
                  <td style={{ fontSize: '0.82rem', color: c.missing_pct > 15 ? '#d97706' : '#64748b' }}>{c.missing_pct}%</td>
                  <td style={{ fontSize: '0.82rem', color: c.inconsistent_pct > 0 ? '#e11d48' : '#64748b' }}>{c.inconsistent_pct}%</td>
                  <td>
                    <StatusBadge status={c.qualification_status} />
                  </td>
                  <td>
                    <button
                      className="btn-outline btn-sm"
                      onClick={() => setActiveModalConsumer(c)}
                    >
                      <Info size={13} />
                      Why This Status?
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drilldown Explanation Modal */}
      {activeModalConsumer && (
        <div style={{
          position: 'fixed',
          top: 0, left: 0, right: 0, bottom: 0,
          backgroundColor: 'rgba(15, 23, 42, 0.65)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
          backdropFilter: 'blur(3px)'
        }}>
          <div style={{
            background: '#ffffff',
            borderRadius: '12px',
            maxWidth: '620px',
            width: '90%',
            padding: '24px',
            boxShadow: 'var(--shadow-lg)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '1px solid #e2e8f0', paddingBottom: '14px', marginBottom: '16px' }}>
              <div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#0f172a' }}>
                  Reliability Qualification Diagnostic
                </h3>
                <div style={{ fontSize: '0.78rem', color: '#64748b' }}>
                  Consumer: {activeModalConsumer.consumer_id} • Meter: {activeModalConsumer.meter_id}
                </div>
              </div>
              <button
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2rem', color: '#94a3b8' }}
                onClick={() => setActiveModalConsumer(null)}
              >
                ✕
              </button>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#334155', marginBottom: 6 }}>
                Qualification Status:
              </div>
              <StatusBadge status={activeModalConsumer.qualification_status} />
            </div>

            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: 8, border: '1px solid #e2e8f0', marginBottom: 16 }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0f172a', marginBottom: 8 }}>
                Transparent Reliability Formula:
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: '#0369a1', lineHeight: 1.5 }}>
                Score = 100 × [(1.0×N_obs + 0.6×N_rec - 2.0×N_incon - 1.2×N_miss - 0.3×N_del) / Total_Slots]
              </div>
              <div style={{ fontSize: '0.78rem', color: '#475569', marginTop: 8 }}>
                Calculated Score: <strong>{activeModalConsumer.reliability_score}%</strong> across {activeModalConsumer.total_slots} transmission intervals.
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#334155', marginBottom: 8 }}>
                Algorithmic Evaluation Reasons:
              </div>
              <ul style={{ paddingLeft: 20, fontSize: '0.82rem', color: '#475569', lineHeight: 1.6 }}>
                {(activeModalConsumer.qualification_reasons || []).map((reason, idx) => (
                  <li key={idx}>{reason}</li>
                ))}
              </ul>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
              <button
                className="btn-outline btn-sm"
                onClick={() => setActiveModalConsumer(null)}
              >
                Close
              </button>
              <button
                className="btn-primary btn-sm"
                onClick={() => {
                  setSelectedConsumer(activeModalConsumer.consumer_id);
                  setActiveModalConsumer(null);
                  setActivePage('passport');
                }}
              >
                Open Evidence Passport
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
