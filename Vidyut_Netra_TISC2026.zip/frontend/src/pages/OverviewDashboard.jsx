import React, { useState, useEffect } from 'react';
import {
  Users,
  ShieldCheck,
  AlertTriangle,
  IndianRupee,
  Activity,
  ArrowRight,
  TrendingDown,
  CheckCircle2,
  Clock,
  Database,
  UploadCloud,
  FileText,
  Wrench,
  HelpCircle,
  RefreshCw
} from 'lucide-react';
import MetricCard from '../components/MetricCard';
import StatusBadge from '../components/StatusBadge';
import { getExecutiveSummary, loadSampleDataset } from '../api';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';

export default function OverviewDashboard({ setActivePage, setSelectedConsumer }) {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadingSample, setLoadingSample] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const sumRes = await getExecutiveSummary();
      setSummary(sumRes.data);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLoad = async () => {
    try {
      setLoadingSample(true);
      await loadSampleDataset();
      await loadDashboardData();
    } catch (err) {
      alert('Error loading demonstration benchmark: ' + (err.response?.data?.error || err.message));
    } finally {
      setLoadingSample(false);
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <Activity className="animate-spin" size={32} style={{ margin: '0 auto 12px auto', color: '#0284c7' }} />
          <div>Loading Vidyut Netra Executive Grid Analytics...</div>
        </div>
      </div>
    );
  }

  // Empty state handling when no dataset is present (Point 14)
  if (!summary || summary.is_empty || summary.total_consumers_monitored === 0) {
    return (
      <div className="card" style={{ padding: '64px 32px', textAlign: 'center', maxWidth: '720px', margin: '40px auto' }}>
        <Database size={48} color="#94a3b8" style={{ margin: '0 auto 16px auto' }} />
        <h2 style={{ fontSize: '1.35rem', fontWeight: 800, color: '#0f172a', marginBottom: 8 }}>
          No Smart-Meter Telemetry Dataset Loaded
        </h2>
        <p style={{ fontSize: '0.88rem', color: '#64748b', lineHeight: 1.6, marginBottom: 24 }}>
          Vidyut Netra operates on live or uploaded smart-meter telemetry. Upload a CSV file containing 
          meter readings (with columns <code>consumer_id, meter_id, timestamp, consumption</code>) or 
          load the pre-configured Telangana 859-record demonstration benchmark.
        </p>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 14 }}>
          <button className="btn-primary" onClick={() => setActivePage('upload')}>
            <UploadCloud size={16} /> Go to Smart-Meter Upload
          </button>
          <button className="btn-outline" onClick={handleQuickLoad} disabled={loadingSample}>
            <Database size={16} /> {loadingSample ? 'Loading Demo Benchmark...' : 'Load Synthetic Benchmark'}
          </button>
        </div>
      </div>
    );
  }

  // Evidence Qualification Breakdown from actual backend engine classifications (Point 7)
  const relPieData = [
    { name: 'Sufficient Evidence', value: summary.sufficient_count || 0, color: '#059669' },
    { name: 'Uncertain Quality', value: summary.uncertain_count || 0, color: '#d97706' },
    { name: 'Unreliable Telemetry', value: summary.unreliable_count || 0, color: '#e11d48' },
  ];

  // Dynamic Category Revenue Exposure from uploaded dataset (Point 9 & 10)
  const categoryChartData = (summary.category_revenue_exposure || []).map(item => ({
    category: item.category,
    'Estimated Exposure': item.estimated_loss || 0,
    'Verified Recovery': item.has_verified_recovery ? (item.actual_recovered || 0) : 0,
    hasVerified: item.has_verified_recovery
  }));

  return (
    <div>
      {/* Dataset Provenance Banner (Point 4: Clearly distinguish synthetic vs actual DISCOM data) */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px', flexWrap: 'wrap', gap: 10 }}>
        {summary.is_synthetic ? (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '5px 14px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 6, fontSize: '0.78rem', fontWeight: 700, color: '#1d4ed8' }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#2563eb' }}></span>
            DATASET STATUS: SYNTHETIC DEMONSTRATION BENCHMARK ({summary.dataset_name}) — Controlled Evaluation Data
          </div>
        ) : (
          <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '5px 14px', background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: 6, fontSize: '0.78rem', fontWeight: 700, color: '#047857' }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#059669' }}></span>
            DATASET STATUS: LIVE DISCOM PRODUCTION TELEMETRY ({summary.dataset_name}) — Live Grid Telemetry
          </div>
        )}

        <button
          className="btn-outline btn-sm"
          onClick={loadDashboardData}
          title="Refresh Dashboard Metrics from Backend"
        >
          <RefreshCw size={13} /> Refresh Metrics
        </button>
      </div>

      {/* Research Innovation Alert Banner */}
      <div className="research-alert">
        <ShieldCheck size={20} color="#2563eb" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title">Vidyut Netra Research Contribution: Reliability-Aware Revenue Assurance</div>
          <div className="alert-desc">
            Conventional smart-grid anomaly detection naively treats missing telemetry or sensor drift as electricity theft, 
            generating up to 45% false alarms. Vidyut Netra qualifies telemetry through a 5-category Measurement Reliability Engine 
            (Observed, Missing, Reconstructed, Inconsistent, Delayed), ensuring DISCOM field squads only investigate verified anomalies 
            while routing hardware failures to maintenance teams.
          </div>
        </div>
      </div>

      {/* KPI Metrics Grid (Points 1, 2, 3, 5, 6, 8) */}
      <div className="metrics-grid">
        {/* KPI 1: Meters & Readings direct from uploaded CSV */}
        <MetricCard
          label="Smart Meters Monitored"
          value={summary.total_meters_monitored || summary.total_consumers_monitored}
          subtext={`${(summary.total_readings_processed || 0).toLocaleString()} Readings across ${summary.total_consumers_monitored} Consumers`}
          icon={Users}
          color="#0284c7"
          bg="#e0f2fe"
        />

        {/* KPI 2: Potential Revenue at Risk */}
        <MetricCard
          label="Potential Revenue at Risk"
          value={`₹${(summary.total_estimated_recoverable_revenue_inr || 0).toLocaleString()}`}
          subtext={`Calculated from ${summary.anomalies_flagged || 0} Flagged Deviations`}
          icon={TrendingDown}
          color="#dc2626"
          bg="#fef2f2"
        />

        {/* KPI 3: Measurement Reliability Qualification Rate */}
        <MetricCard
          label="Reliability Qualification Rate"
          value={`${summary.measurement_reliability_rate || 0}%`}
          subtext={`${summary.sufficient_count || 0} Meters Qualified as Eligible for Inspection Review`}
          icon={ShieldCheck}
          color="#059669"
          bg="#ecfdf5"
        />

        {/* KPI 4: Verified Ground Truth Recovery (Points 2 & 3: Not fabricated) */}
        <MetricCard
          label="Confirmed Revenue Recovered"
          value={
            summary.has_verified_inspections && summary.actual_recovered_revenue_inr !== null
              ? `₹${summary.actual_recovered_revenue_inr.toLocaleString()}`
              : "Not Available"
          }
          subtext={
            summary.has_verified_inspections && summary.actual_recovered_revenue_inr !== null
              ? `₹${(summary.penalties_levied_inr || 0).toLocaleString()} Penalties (${summary.confirmed_theft_cases} Confirmed Thefts)`
              : "Pending Field Inspection Ground Truth"
          }
          icon={IndianRupee}
          color="#7c3aed"
          bg="#f5f3ff"
        />
      </div>

      {/* Charts Section */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '24px' }}>
        {/* Measurement Reliability Qualification Chart (Point 7) */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Evidence Qualification Breakdown</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: 500 }}>
              Module 3 Telemetry Engine
            </span>
          </div>
          <div style={{ height: '240px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={relPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {relPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value, name) => [`${value} Meters (${summary.total_consumers_monitored > 0 ? ((value / summary.total_consumers_monitored)*100).toFixed(1) : 0}%)`, name]}
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                />
                <Legend verticalAlign="bottom" height={36} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Dynamic Revenue Exposure by Consumer Category Chart (Point 9 & 10) */}
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Revenue Exposure by Consumer Category</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b', fontWeight: 500 }}>
              Actual Dataset Categories
            </span>
          </div>
          <div style={{ height: '240px' }}>
            {categoryChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={categoryChartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <XAxis dataKey="category" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`} />
                  <Tooltip
                    formatter={(val, name) => [
                      `₹${val.toLocaleString()}`,
                      name === 'Estimated Exposure' ? 'Estimated Exposure (AI Calculation)' : 'Actual Verified Recovery (Field Ground Truth)'
                    ]}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', border: '1px solid #e2e8f0' }}
                  />
                  <Legend />
                  <Bar dataKey="Estimated Exposure" fill="#f87171" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Verified Recovery" fill="#34d399" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: '#94a3b8', fontSize: '0.85rem' }}>
                No category data available in current dataset
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Priority Action Queue (Point 11 & 12: Connected to actual prioritization, excluding unreliable evidence from theft) */}
      <div className="card">
        <div className="card-title">
          <span>Priority Action Queue (AI Flagged & Reliability Qualified)</span>
          <button
            className="btn-outline btn-sm"
            onClick={() => setActivePage('prioritization')}
          >
            View All Work Orders
            <ArrowRight size={14} />
          </button>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Consumer ID</th>
                <th>Meter ID</th>
                <th>Category</th>
                <th>Anomaly Score</th>
                <th>Reliability Qualification</th>
                <th>Recommended Action</th>
                <th>Est. Recovery</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {(summary.priority_action_queue || []).map((item) => (
                <tr key={item.consumer_id}>
                  <td style={{ fontWeight: 800, color: item.priority_rank <= 3 ? '#dc2626' : '#64748b' }}>
                    #{item.priority_rank}
                  </td>
                  <td className="code-cell">{item.consumer_id}</td>
                  <td className="code-cell" style={{ color: '#475569' }}>{item.meter_id}</td>
                  <td>{item.consumer_category}</td>
                  <td>
                    <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, color: item.anomaly_score >= 0.6 ? '#dc2626' : '#ea580c' }}>
                      {item.anomaly_score.toFixed(3)}
                    </span>
                  </td>
                  <td>
                    <StatusBadge status={item.reliability_status} />
                  </td>
                  <td>
                    <StatusBadge status={item.recommended_action} />
                  </td>
                  <td style={{ fontWeight: 700, color: '#0f172a' }}>
                    ₹{(item.estimated_recoverable_value || 0).toLocaleString()}
                  </td>
                  <td>
                    <button
                      className="btn-primary btn-sm"
                      onClick={() => {
                        setSelectedConsumer(item.consumer_id);
                        setActivePage('passport');
                      }}
                    >
                      <FileText size={13} />
                      Evidence Passport
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
