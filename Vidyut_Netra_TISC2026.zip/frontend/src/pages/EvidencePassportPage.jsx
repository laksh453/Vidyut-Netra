import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Printer,
  ShieldCheck,
  AlertTriangle,
  Info,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Clock,
  Layers,
  Zap,
  Activity,
  ArrowLeft,
  ChevronDown,
  Building,
  Calendar,
  AlertCircle,
  Save,
  Paperclip,
  Check,
  UserCheck,
  ExternalLink,
  Upload
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import {
  getEvidencePassport,
  getAnomalyResults,
  saveFieldVerification,
  uploadVerificationAttachment
} from '../api';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip
} from 'recharts';

export default function EvidencePassportPage({ selectedConsumer, setSelectedConsumer, setActivePage }) {
  const [passport, setPassport] = useState(null);
  const [availableConsumers, setAvailableConsumers] = useState([]);
  const [loading, setLoading] = useState(true);

  // Field Verification Form State
  const [checklist, setChecklist] = useState([]);
  const [officerId, setOfficerId] = useState('K. Venkat (ADE/DPE)');
  const [inspectionDate, setInspectionDate] = useState(new Date().toISOString().slice(0, 10));
  const [finalOutcome, setFinalOutcome] = useState('Suspected irregularity requiring further investigation');
  const [overallNotes, setOverallNotes] = useState('');
  const [overallAttachment, setOverallAttachment] = useState('');
  const [savingVerification, setSavingVerification] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(null);
  const [saveError, setSaveError] = useState(null);
  const [uploadingCheckIndex, setUploadingCheckIndex] = useState(null);

  const fileInputRefs = useRef({});
  const overallFileInputRef = useRef(null);

  useEffect(() => {
    loadConsumerList();
  }, []);

  useEffect(() => {
    if (selectedConsumer) {
      loadPassport(selectedConsumer);
    } else if (availableConsumers.length > 0) {
      loadPassport(availableConsumers[0].consumer_id);
    }
  }, [selectedConsumer, availableConsumers]);

  const loadConsumerList = async () => {
    try {
      const res = await getAnomalyResults();
      const list = res.data.results || [];
      setAvailableConsumers(list);
      if (!selectedConsumer && list.length > 0) {
        const highRisk = list.find(c => c.risk_level === 'CRITICAL' || c.risk_level === 'HIGH');
        const defaultId = highRisk ? highRisk.consumer_id : list[0].consumer_id;
        setSelectedConsumer(defaultId);
      }
    } catch (err) {
      console.error('Failed to load consumer list:', err);
    }
  };

  const loadPassport = async (consumerId) => {
    try {
      setLoading(true);
      setSaveSuccess(null);
      setSaveError(null);
      const res = await getEvidencePassport(consumerId);
      const pData = res.data;
      setPassport(pData);

      // Populate checklist
      setChecklist(pData.sop_verification_checklist || []);

      // Populate verification metadata if already saved
      if (pData.verification_audit?.is_verified) {
        setOfficerId(pData.verification_audit.officer_id || 'K. Venkat (ADE/DPE)');
        setInspectionDate(pData.verification_audit.inspection_date || new Date().toISOString().slice(0, 10));
        setFinalOutcome(pData.verification_audit.final_outcome || 'Suspected irregularity requiring further investigation');
        setOverallNotes(pData.verification_audit.overall_notes || '');
        setOverallAttachment(pData.verification_audit.attachment_name || '');
      } else {
        setOverallNotes('');
        setOverallAttachment('');
      }
    } catch (err) {
      console.error('Failed to load passport:', err);
    } finally {
      setLoading(false);
    }
  };

  // Checklist Item Status Handler (PASS, FAIL, NOT_VERIFIED)
  const setCheckStatus = (idx, status) => {
    const updated = [...checklist];
    updated[idx] = {
      ...updated[idx],
      status: status
    };
    setChecklist(updated);
  };

  // Checklist Item Notes Handler
  const setCheckNotes = (idx, notes) => {
    const updated = [...checklist];
    updated[idx] = {
      ...updated[idx],
      notes: notes
    };
    setChecklist(updated);
  };

  // Handle Checklist Item Attachment Upload
  const handleCheckAttachmentUpload = async (idx, file) => {
    if (!file) return;
    try {
      setUploadingCheckIndex(idx);
      const formData = new FormData();
      formData.append('file', file);
      const res = await uploadVerificationAttachment(formData);
      if (res.data.success) {
        const updated = [...checklist];
        updated[idx] = {
          ...updated[idx],
          attachment_name: res.data.filename
        };
        setChecklist(updated);
      }
    } catch (err) {
      alert('Error uploading attachment: ' + (err.response?.data?.error || err.message));
    } finally {
      setUploadingCheckIndex(null);
    }
  };

  // Handle Overall Attachment Upload
  const handleOverallAttachmentUpload = async (file) => {
    if (!file) return;
    try {
      const formData = new FormData();
      formData.append('file', file);
      const res = await uploadVerificationAttachment(formData);
      if (res.data.success) {
        setOverallAttachment(res.data.filename);
      }
    } catch (err) {
      alert('Error uploading document: ' + (err.response?.data?.error || err.message));
    }
  };

  // Save Inspection Results to Database
  const handleSaveInspection = async () => {
    if (!passport) return;
    try {
      setSavingVerification(true);
      setSaveError(null);
      setSaveSuccess(null);

      const payload = {
        consumer_id: passport.consumer_id,
        meter_id: passport.meter_id,
        officer_id: officerId,
        inspection_date: inspectionDate,
        final_outcome: finalOutcome,
        checklist: checklist,
        overall_notes: overallNotes,
        attachment_name: overallAttachment
      };

      const res = await saveFieldVerification(payload);
      if (res.data.success) {
        setSaveSuccess(`Inspection verification results for ${passport.consumer_id} saved persistently to database and synchronized with the Inspection Feedback loop!`);
        // Refresh passport to update counters
        const refreshed = await getEvidencePassport(passport.consumer_id);
        setPassport(refreshed.data);
      }
    } catch (err) {
      setSaveError(err.response?.data?.error || err.message || 'Failed to save inspection results.');
    } finally {
      setSavingVerification(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  // Verification Counts
  const completedCount = checklist.filter(c => c.status === 'PASS' || c.status === 'FAIL').length;
  const pendingCount = checklist.filter(c => c.status !== 'PASS' && c.status !== 'FAIL').length;
  const totalCount = checklist.length || 6;

  if (loading && !passport) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '60vh' }}>
        <div style={{ textAlign: 'center', color: '#64748b' }}>
          <Activity className="animate-spin" size={32} style={{ margin: '0 auto 12px auto', color: '#0284c7' }} />
          <div>Compiling Explainable Evidence Passport & Audit Records...</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Top Action & Selector Bar (Hidden during Print) */}
      <div className="no-print" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <button
            className="btn-outline btn-sm"
            onClick={() => setActivePage('anomaly')}
          >
            <ArrowLeft size={14} />
            Back to Anomalies
          </button>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: '0.85rem', fontWeight: 600, color: '#334155' }}>Select Consumer:</span>
            <select
              className="form-select"
              value={selectedConsumer || ''}
              onChange={(e) => {
                setSelectedConsumer(e.target.value);
                loadPassport(e.target.value);
              }}
              style={{ width: '320px', fontSize: '0.85rem', fontWeight: 600 }}
            >
              {availableConsumers.map((c) => (
                <option key={c.consumer_id} value={c.consumer_id}>
                  {c.consumer_id} ({c.consumer_category} • {c.risk_level})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <button
            className="btn-outline btn-sm"
            onClick={() => {
              if (setActivePage) {
                setActivePage('feedback');
              }
            }}
            title="Jump to Inspection Feedback Module"
          >
            <ExternalLink size={14} />
            View in Inspection Feedback
          </button>

          <button
            className="btn-primary btn-sm"
            onClick={handlePrint}
          >
            <Printer size={15} />
            Print / Export Official Dossier (PDF)
          </button>
        </div>
      </div>

      {passport && (
        <div className="passport-container">
          <div className="passport-watermark">VIDYUT NETRA • AUDIT DOSSIER</div>

          {/* Dossier Header */}
          <div className="passport-header">
            <div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '0.72rem', letterSpacing: '0.08em', fontWeight: 800, color: '#0284c7', textTransform: 'uppercase', marginBottom: 4 }}>
                <ShieldCheck size={14} />
                TSSPDCL / TSNPDCL • REVENUE ASSURANCE INTELLIGENCE DOSSIER
              </div>
              <h2 style={{ fontSize: '1.45rem', fontWeight: 800, color: '#0f172a' }}>
                Evidence Passport: {passport.consumer_id}
              </h2>
              <div style={{ fontSize: '0.82rem', color: '#64748b', marginTop: 4 }}>
                Smart Meter ID: <strong>{passport.meter_id}</strong> • Transformer: <strong>{passport.transformer_id}</strong> • Tariff: <strong>{passport.consumer_category}</strong>
              </div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Dossier Reference ID</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.88rem', fontWeight: 700, color: '#0369a1' }}>
                {passport.passport_id}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
                Generated: {passport.generated_at}
              </div>
            </div>
          </div>

          {/* Human Verification Status Banner */}
          <div style={{
            marginBottom: '20px',
            padding: '12px 16px',
            borderRadius: '8px',
            border: passport.verification_audit?.is_verified ? '1px solid #a7f3d0' : '1px solid #fed7aa',
            backgroundColor: passport.verification_audit?.is_verified ? '#f0fdf4' : '#fffbeb',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            flexWrap: 'wrap',
            gap: 12
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              {passport.verification_audit?.is_verified ? (
                <UserCheck size={22} color="#059669" />
              ) : (
                <AlertCircle size={22} color="#ea580c" />
              )}
              <div>
                <div style={{ fontSize: '0.85rem', fontWeight: 800, color: passport.verification_audit?.is_verified ? '#065f46' : '#9a3412' }}>
                  {passport.verification_audit?.is_verified ? 'HUMAN FIELD VERIFICATION COMPLETED & RECORDED' : 'PENDING HUMAN FIELD VERIFICATION'}
                </div>
                <div style={{ fontSize: '0.75rem', color: passport.verification_audit?.is_verified ? '#047857' : '#c2410c' }}>
                  {passport.verification_audit?.is_verified ? (
                    <>
                      Verified by: <strong>{passport.verification_audit.officer_id}</strong> on <strong>{passport.verification_audit.inspection_date}</strong> • Outcome: <strong>{passport.verification_audit.final_outcome}</strong>
                    </>
                  ) : (
                    'AI anomaly flags are preliminary indicators and require physical on-site validation by authorized squad officers.'
                  )}
                </div>
              </div>
            </div>

            {/* Checklist Progress Pill */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: '0.74rem', fontWeight: 700, padding: '3px 8px', borderRadius: 4, background: '#ecfdf5', color: '#059669', border: '1px solid #a7f3d0' }}>
                Completed: {completedCount} / {totalCount}
              </span>
              <span style={{ fontSize: '0.74rem', fontWeight: 700, padding: '3px 8px', borderRadius: 4, background: pendingCount === 0 ? '#f1f5f9' : '#fff7ed', color: pendingCount === 0 ? '#64748b' : '#c2410c', border: pendingCount === 0 ? '1px solid #cbd5e1' : '1px solid #fed7aa' }}>
                Pending: {pendingCount} / {totalCount}
              </span>
            </div>
          </div>

          {/* Section Divider: AI Algorithmic Diagnostic Findings */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ background: '#eff6ff', color: '#1d4ed8', fontSize: '0.74rem', fontWeight: 800, padding: '3px 8px', borderRadius: 4, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              SECTION A • AI Algorithmic Diagnostic Findings
            </span>
            <div style={{ flex: 1, height: 1, background: '#e2e8f0' }} />
          </div>

          {/* Core Findings Summary Cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '14px', marginBottom: '24px' }}>
            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.74rem', color: '#64748b', fontWeight: 600 }}>POTENTIAL ANOMALY STATUS</div>
              <div style={{ marginTop: 6 }}>
                <StatusBadge status={passport.risk_level} />
              </div>
              <div style={{ fontSize: '0.72rem', color: '#475569', marginTop: 6 }}>
                Isolation Forest Outlier Flagged
              </div>
            </div>

            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.74rem', color: '#64748b', fontWeight: 600 }}>MODEL ANOMALY SCORE</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: passport.model_anomaly_score >= 0.6 ? '#dc2626' : '#ea580c', marginTop: 4 }}>
                {passport.model_anomaly_score.toFixed(3)}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b' }}>
                Normalized Decision Distance [0-1]
              </div>
            </div>

            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.74rem', color: '#64748b', fontWeight: 600 }}>MEASUREMENT RELIABILITY</div>
              <div style={{ marginTop: 6 }}>
                <StatusBadge status={passport.reliability_qualification_status} />
              </div>
              <div style={{ fontSize: '0.72rem', color: '#475569', marginTop: 6 }}>
                Reliability Score: <strong>{passport.reliability_score}%</strong>
              </div>
            </div>

            <div style={{ background: '#f8fafc', padding: '14px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.74rem', color: '#64748b', fontWeight: 600 }}>ANALYSIS TIMEFRAME</div>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', marginTop: 6 }}>
                {passport.analysis_period}
              </div>
              <div style={{ fontSize: '0.72rem', color: '#64748b', marginTop: 4 }}>
                30-Day Chronological Window
              </div>
            </div>
          </div>

          {/* Consumption Trend & Supporting Meter Readings Chart */}
          <div style={{ marginBottom: '24px' }}>
            <div style={{ fontSize: '0.9rem', fontWeight: 700, color: '#0f172a', marginBottom: '10px', display: 'flex', justifyContent: 'space-between' }}>
              <span>Supporting Smart-Meter Telemetry Trend (Historical Baseline vs Flagged Period)</span>
              <span style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 500 }}>Daily Aggregated Energy (kWh)</span>
            </div>

            <div style={{ height: '220px', background: '#f8fafc', padding: '12px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={passport.consumption_trend || []} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="consumptionGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="timestamp" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '0.8rem' }}
                    formatter={(val) => [`${val} kWh`, 'Consumption']}
                  />
                  <Area type="monotone" dataKey="consumption" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill="url(#consumptionGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Explainable AI Evidence Grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: '20px', marginBottom: '28px' }}>
            {/* Contributing Behavioral Features */}
            <div style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Zap size={16} color="#d97706" />
                <span>Primary Algorithmic Reasons & Contributing Factors</span>
              </div>

              <div style={{ marginBottom: 12 }}>
                {(passport.reasons_for_flagging || []).map((reason, idx) => (
                  <div key={idx} style={{ padding: '8px 10px', background: '#fff7ed', borderLeft: '3px solid #ea580c', borderRadius: 4, fontSize: '0.8rem', color: '#9a3412', marginBottom: 6 }}>
                    • {reason}
                  </div>
                ))}
              </div>

              <div style={{ fontSize: '0.78rem', color: '#475569' }}>
                {(passport.important_contributing_features || []).map((feat, idx) => (
                  <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f1f5f9' }}>
                    <span style={{ fontWeight: 600 }}>{feat.feature}:</span>
                    <span style={{ fontFamily: 'var(--font-mono)', color: '#dc2626', fontWeight: 700 }}>{feat.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Plausible Alternative Benign Explanations */}
            <div style={{ border: '1px solid #e2e8f0', borderRadius: '8px', padding: '16px', background: '#f8fafc' }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Info size={16} color="#059669" />
                <span>Plausible Benign Alternative Explanations</span>
              </div>
              <div style={{ fontSize: '0.78rem', color: '#64748b', marginBottom: 10 }}>
                DISCOM squads must verify these legitimate conditions before alleging illegal abstraction:
              </div>

              {(passport.plausible_alternative_explanations || []).map((alt, idx) => (
                <div key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, padding: '6px 0', fontSize: '0.8rem', color: '#334155' }}>
                  <span style={{ color: '#059669', fontWeight: 700 }}>✓</span>
                  <span>{alt}</span>
                </div>
              ))}

              <div style={{ marginTop: 14, padding: '10px', background: '#ecfdf5', borderRadius: 6, border: '1px solid #a7f3d0', fontSize: '0.74rem', color: '#065f46' }}>
                <strong>Ethical Revenue Assurance Mandate:</strong> An unusual consumption pattern is NOT evidence of theft. Payment disputes or delays must not be treated as theft indicators.
              </div>
            </div>
          </div>

          {/* Section Divider: Human Field Squad Verification Record */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
            <span style={{ background: '#f0fdf4', color: '#15803d', fontSize: '0.74rem', fontWeight: 800, padding: '3px 8px', borderRadius: 4, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
              SECTION B • Human Field Squad Verification Record (Ground Truth)
            </span>
            <div style={{ flex: 1, height: 1, background: '#cbd5e1' }} />
          </div>

          {/* Standard Operating Procedure (SOP) Field Verification Checklist with Recording */}
          <div style={{ border: '2px solid #0284c7', borderRadius: '8px', padding: '20px', marginBottom: '24px', background: '#ffffff' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, flexWrap: 'wrap', gap: 10 }}>
              <div>
                <h3 style={{ fontSize: '1.05rem', fontWeight: 800, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <ShieldCheck size={20} color="#0284c7" />
                  Standard Operating Procedure (SOP) 6-Point Field Squad Verification
                </h3>
                <div style={{ fontSize: '0.78rem', color: '#64748b', marginTop: 2 }}>
                  Record on-site findings with Pass / Fail / Not Verified statuses, inspection notes, and supporting attachments.
                </div>
              </div>

              {/* Progress Counters */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '0.72rem', color: '#64748b' }}>Verification Status</div>
                  <div style={{ fontSize: '0.85rem', fontWeight: 800, color: completedCount === totalCount ? '#059669' : '#0284c7' }}>
                    {completedCount} of {totalCount} Checks Completed
                  </div>
                </div>
                <div style={{ width: '80px', height: '8px', background: '#e2e8f0', borderRadius: '4px', overflow: 'hidden' }}>
                  <div
                    style={{
                      width: `${(completedCount / totalCount) * 100}%`,
                      height: '100%',
                      background: completedCount === totalCount ? '#059669' : '#0284c7',
                      transition: 'width 0.3s ease'
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Checklist Items */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginBottom: 20 }}>
              {checklist.map((item, idx) => {
                const status = item.status || 'NOT_VERIFIED';
                return (
                  <div
                    key={item.step}
                    style={{
                      border: status === 'PASS' ? '1px solid #86efac' : (status === 'FAIL' ? '1px solid #fca5a5' : '1px solid #e2e8f0'),
                      borderRadius: '8px',
                      padding: '14px 16px',
                      backgroundColor: status === 'PASS' ? '#f0fdf4' : (status === 'FAIL' ? '#fef2f2' : '#f8fafc'),
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
                      {/* Step Info */}
                      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, flex: 1, minWidth: '280px' }}>
                        <div
                          style={{
                            width: '28px',
                            height: '28px',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontWeight: 800,
                            fontSize: '0.82rem',
                            flexShrink: 0,
                            backgroundColor: status === 'PASS' ? '#059669' : (status === 'FAIL' ? '#dc2626' : '#64748b'),
                            color: '#ffffff'
                          }}
                        >
                          {status === 'PASS' ? '✓' : (status === 'FAIL' ? '✕' : item.step)}
                        </div>

                        <div>
                          <div style={{ fontSize: '0.88rem', fontWeight: 700, color: '#0f172a' }}>
                            Step {item.step}: {item.action}
                          </div>
                          <div style={{ fontSize: '0.76rem', color: '#475569', marginTop: 3, lineHeight: 1.4 }}>
                            {item.instruction}
                          </div>
                        </div>
                      </div>

                      {/* Status Selector Buttons (Requirement 1: Pass, Fail, Not Verified) */}
                      <div className="no-print" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <button
                          type="button"
                          onClick={() => setCheckStatus(idx, 'PASS')}
                          style={{
                            padding: '4px 10px',
                            fontSize: '0.74rem',
                            fontWeight: 700,
                            borderRadius: '4px',
                            border: status === 'PASS' ? '1px solid #059669' : '1px solid #cbd5e1',
                            background: status === 'PASS' ? '#059669' : '#ffffff',
                            color: status === 'PASS' ? '#ffffff' : '#334155',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4
                          }}
                        >
                          <CheckCircle2 size={13} />
                          Pass
                        </button>

                        <button
                          type="button"
                          onClick={() => setCheckStatus(idx, 'FAIL')}
                          style={{
                            padding: '4px 10px',
                            fontSize: '0.74rem',
                            fontWeight: 700,
                            borderRadius: '4px',
                            border: status === 'FAIL' ? '1px solid #dc2626' : '1px solid #cbd5e1',
                            background: status === 'FAIL' ? '#dc2626' : '#ffffff',
                            color: status === 'FAIL' ? '#ffffff' : '#334155',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4
                          }}
                        >
                          <XCircle size={13} />
                          Fail
                        </button>

                        <button
                          type="button"
                          onClick={() => setCheckStatus(idx, 'NOT_VERIFIED')}
                          style={{
                            padding: '4px 10px',
                            fontSize: '0.74rem',
                            fontWeight: 700,
                            borderRadius: '4px',
                            border: status === 'NOT_VERIFIED' ? '1px solid #64748b' : '1px solid #cbd5e1',
                            background: status === 'NOT_VERIFIED' ? '#64748b' : '#ffffff',
                            color: status === 'NOT_VERIFIED' ? '#ffffff' : '#334155',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            gap: 4
                          }}
                        >
                          <HelpCircle size={13} />
                          Not Verified
                        </button>
                      </div>

                      {/* Print view badge */}
                      <div className="print-only">
                        <span style={{
                          fontWeight: 700,
                          fontSize: '0.78rem',
                          color: status === 'PASS' ? '#059669' : (status === 'FAIL' ? '#dc2626' : '#64748b')
                        }}>
                          [{status}]
                        </span>
                      </div>
                    </div>

                    {/* Officer Notes & Evidence Attachment (Requirements 2 & 3) */}
                    <div style={{ marginTop: 10, display: 'grid', gridTemplateColumns: '1fr auto', gap: 10, alignItems: 'center' }}>
                      <input
                        type="text"
                        placeholder="Officer observations / specific findings for this check (e.g. Seal #8492 cut, CT secondary bypassed)..."
                        value={item.notes || ''}
                        onChange={(e) => setCheckNotes(idx, e.target.value)}
                        className="form-input"
                        style={{ fontSize: '0.78rem', padding: '6px 10px', height: '32px' }}
                      />

                      <div className="no-print" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <input
                          type="file"
                          ref={el => fileInputRefs.current[idx] = el}
                          onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                              handleCheckAttachmentUpload(idx, e.target.files[0]);
                            }
                          }}
                          style={{ display: 'none' }}
                          accept="image/*,.pdf,.doc,.docx"
                        />

                        {item.attachment_name ? (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 4, background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 4, padding: '4px 8px', fontSize: '0.74rem', color: '#1d4ed8' }}>
                            <Paperclip size={12} />
                            <span style={{ maxWidth: '120px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={item.attachment_name}>
                              {item.attachment_name}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                const updated = [...checklist];
                                updated[idx].attachment_name = '';
                                setChecklist(updated);
                              }}
                              style={{ background: 'transparent', border: 'none', color: '#dc2626', cursor: 'pointer', fontWeight: 800, padding: 0 }}
                            >
                              ✕
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            className="btn-outline btn-sm"
                            style={{ padding: '4px 8px', fontSize: '0.74rem' }}
                            onClick={() => fileInputRefs.current[idx]?.click()}
                            disabled={uploadingCheckIndex === idx}
                          >
                            <Paperclip size={12} />
                            {uploadingCheckIndex === idx ? 'Uploading...' : 'Attach Proof'}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Verification Metadata Form (Requirements 4 & 8: Date, Officer, Outcome, Overall Notes) */}
            <div style={{ background: '#f8fafc', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0', marginTop: 16 }}>
              <div style={{ fontSize: '0.85rem', fontWeight: 800, color: '#0f172a', marginBottom: 12 }}>
                Officer Verification Sign-off & Final Determination
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.3fr', gap: 14, marginBottom: 12 }}>
                <div>
                  <label className="form-label">Inspecting Officer Identifier / Name</label>
                  <input
                    type="text"
                    className="form-input"
                    value={officerId}
                    onChange={(e) => setOfficerId(e.target.value)}
                    placeholder="e.g. K. Venkat (ADE/DPE)"
                    style={{ fontSize: '0.82rem' }}
                  />
                </div>

                <div>
                  <label className="form-label">Inspection Date</label>
                  <input
                    type="date"
                    className="form-input"
                    value={inspectionDate}
                    onChange={(e) => setInspectionDate(e.target.value)}
                    style={{ fontSize: '0.82rem' }}
                  />
                </div>

                {/* Requirement 8: Final Inspection Outcome Dropdown */}
                <div>
                  <label className="form-label" style={{ fontWeight: 700, color: '#0f172a' }}>
                    Final Verified Outcome (DISCOM Ground Truth)
                  </label>
                  <select
                    className="form-select"
                    value={finalOutcome}
                    onChange={(e) => setFinalOutcome(e.target.value)}
                    style={{ fontSize: '0.82rem', fontWeight: 700 }}
                  >
                    <option value="Confirmed technical issue">Confirmed technical issue</option>
                    <option value="Confirmed meter issue">Confirmed meter issue</option>
                    <option value="Legitimate consumption variation">Legitimate consumption variation</option>
                    <option value="Suspected irregularity requiring further investigation">Suspected irregularity requiring further investigation</option>
                    <option value="Inconclusive">Inconclusive</option>
                  </select>
                </div>
              </div>

              <div style={{ marginBottom: 14 }}>
                <label className="form-label">Comprehensive Officer Findings & Concluding Summary</label>
                <textarea
                  className="form-input"
                  rows={2}
                  value={overallNotes}
                  onChange={(e) => setOverallNotes(e.target.value)}
                  placeholder="Record full physical verification synopsis, reference meter differential readings, consumer statement, and recommended administrative action..."
                  style={{ fontSize: '0.82rem', resize: 'vertical' }}
                />
              </div>

              {/* Requirement 3: Overall Dossier Document Attachment */}
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <input
                    type="file"
                    ref={overallFileInputRef}
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        handleOverallAttachmentUpload(e.target.files[0]);
                      }
                    }}
                    style={{ display: 'none' }}
                    accept="image/*,.pdf,.doc,.docx"
                  />

                  <button
                    type="button"
                    className="btn-outline btn-sm"
                    onClick={() => overallFileInputRef.current?.click()}
                  >
                    <Upload size={14} />
                    Attach Site Photo / Test Dossier (PDF/Image)
                  </button>

                  {overallAttachment && (
                    <span style={{ fontSize: '0.78rem', color: '#0284c7', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4 }}>
                      <Paperclip size={13} />
                      Attached: {overallAttachment}
                    </span>
                  )}
                </div>

                {/* Requirement 5: Save Inspection Results Button */}
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleSaveInspection}
                  disabled={savingVerification}
                  style={{ padding: '8px 20px', fontSize: '0.88rem', fontWeight: 800, backgroundColor: '#059669', borderColor: '#059669' }}
                >
                  <Save size={16} />
                  {savingVerification ? 'Saving to Database...' : 'Save Inspection Results'}
                </button>
              </div>

              {/* Success / Error Banners */}
              {saveSuccess && (
                <div style={{ marginTop: 12, padding: '10px 14px', background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: 6, color: '#059669', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <CheckCircle2 size={16} />
                  {saveSuccess}
                </div>
              )}

              {saveError && (
                <div style={{ marginTop: 12, padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 6, color: '#dc2626', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <AlertCircle size={16} />
                  {saveError}
                </div>
              )}
            </div>
          </div>

          {/* Signatures & Model Provenance Footer */}
          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', gap: '20px', borderTop: '1px solid #e2e8f0', paddingTop: '16px', fontSize: '0.74rem', color: '#64748b' }}>
            <div>
              <strong>Model Provenance:</strong> {passport.model_name} (v{passport.model_version})<br />
              Generated via Vidyut Netra Explainable AI Engine • Verification Status: <strong>{passport.verification_audit?.is_verified ? 'RECORDED' : 'PENDING'}</strong>
            </div>

            <div style={{ borderTop: '1px dashed #cbd5e1', paddingTop: '28px', textAlign: 'center' }}>
              Field Inspecting Officer Signature<br />
              <strong style={{ color: '#0f172a' }}>{officerId}</strong>
            </div>

            <div style={{ borderTop: '1px dashed #cbd5e1', paddingTop: '28px', textAlign: 'center' }}>
              Divisional Engineer (DPE) Seal<br />
              <span style={{ fontSize: '0.7rem' }}>TS-DISCOM Revenue Assurance</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
