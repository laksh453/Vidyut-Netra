import React, { useState, useEffect } from 'react';
import {
  ZapOff,
  Sliders,
  Play,
  Search,
  Filter,
  AlertCircle,
  FileText,
  Activity,
  Layers,
  CheckCircle2,
  HelpCircle
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { runAnomalyDetection, getAnomalyResults } from '../api';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';

export default function AnomalyDetectionPage({ setActivePage, setSelectedConsumer }) {
  const [results, setResults] = useState([]);
  const [summary, setSummary] = useState(null);
  const [contamination, setContamination] = useState(0.15);
  const [running, setRunning] = useState(false);
  const [riskFilter, setRiskFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchResults();
  }, [riskFilter]);

  const fetchResults = async () => {
    try {
      setLoading(true);
      const params = {};
      if (riskFilter !== 'ALL') {
        params.risk = riskFilter;
      }
      const res = await getAnomalyResults(params);
      setResults(res.data.results || []);
      setSummary(res.data.summary || null);
    } catch (err) {
      console.error('Error fetching anomalies:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleRunModel = async () => {
    try {
      setRunning(true);
      await runAnomalyDetection({ contamination: parseFloat(contamination) });
      await fetchResults();
    } catch (err) {
      alert('Error running AI model: ' + (err.response?.data?.error || err.message));
    } finally {
      setRunning(false);
    }
  };

  const filteredResults = results.filter(r => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      r.consumer_id.toLowerCase().includes(q) ||
      r.meter_id.toLowerCase().includes(q) ||
      r.consumer_category.toLowerCase().includes(q) ||
      r.transformer_id.toLowerCase().includes(q)
    );
  });

  const riskTierData = summary ? [
    { tier: 'Critical', count: summary.critical_risk_count || 0, color: '#dc2626' },
    { tier: 'High', count: summary.high_risk_count || 0, color: '#ea580c' },
    { tier: 'Medium', count: summary.medium_risk_count || 0, color: '#d97706' },
    { tier: 'Low', count: summary.low_risk_count || 0, color: '#10b981' }
  ] : [];

  return (
    <div>
      {/* Ethical Guardrail Disclaimer */}
      <div className="research-alert warning">
        <AlertCircle size={20} color="#d97706" style={{ flexShrink: 0, marginTop: 2 }} />
        <div>
          <div className="alert-title" style={{ color: '#92400e' }}>
            Responsible AI & Revenue Assurance Ethics Principle
          </div>
          <div className="alert-desc" style={{ color: '#78350f' }}>
            An unusual consumption pattern is <strong>NOT proof of electricity theft</strong>. The Isolation Forest algorithm 
            identifies multidimensional behavioral deviations. Every flagged case generates an explainable Evidence Passport and 
            must be physically verified by field squads. Payment delays or billing disputes are strictly excluded from theft evidence.
          </div>
        </div>
      </div>

      {/* Model Controls Bar */}
      <div className="card" style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.85rem', fontWeight: 600, color: '#334155' }}>
              <Layers size={18} color="#0284c7" />
              <span>Algorithm: <strong>Isolation Forest (Scikit-Learn Ensemble)</strong></span>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: '0.82rem', color: '#64748b' }}>Expected Contamination:</span>
              <input
                type="range"
                min="0.05"
                max="0.30"
                step="0.01"
                value={contamination}
                onChange={(e) => setContamination(e.target.value)}
                style={{ width: '120px', cursor: 'pointer' }}
              />
              <span style={{ fontSize: '0.82rem', fontFamily: 'var(--font-mono)', fontWeight: 700, color: '#0369a1' }}>
                {(contamination * 100).toFixed(0)}%
              </span>
            </div>
          </div>

          <button
            className="btn-primary"
            onClick={handleRunModel}
            disabled={running}
          >
            <Play size={15} fill="#ffffff" />
            {running ? 'Executing Isolation Forest...' : 'Retrain & Run Detection'}
          </button>
        </div>
      </div>

      {/* Risk Tier Distribution */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '20px', marginBottom: '24px' }}>
        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Risk Tier Breakdown</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b' }}>
              Flagged: <strong>{summary?.total_anomalies_flagged || 0} / {summary?.total_analyzed || 0}</strong>
            </span>
          </div>
          <div style={{ height: '180px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={riskTierData} layout="vertical" margin={{ top: 10, right: 20, left: 50, bottom: 0 }}>
                <XAxis type="number" tick={{ fontSize: 11 }} />
                <YAxis type="category" dataKey="tier" tick={{ fontSize: 11 }} />
                <Tooltip formatter={(val) => [`${val} Meters`, 'Count']} />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {riskTierData.map((entry, idx) => (
                    <Cell key={`cell-${idx}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card" style={{ marginBottom: 0 }}>
          <div className="card-title">
            <span>Feature Engineering & Behavioral Deviation Vector</span>
            <span style={{ fontSize: '0.78rem', color: '#64748b' }}>Scikit-Learn ML Attributes</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
            <div style={{ background: '#f8fafc', padding: 10, borderRadius: 6, border: '1px solid #e2e8f0', fontSize: '0.78rem' }}>
              <div style={{ color: '#64748b' }}>Recent 7-Day Drop Ratio</div>
              <div style={{ fontWeight: 700, color: '#0f172a', marginTop: 4 }}>Δ Historical Baseline</div>
              <div style={{ color: '#94a3b8', fontSize: '0.72rem' }}>Identifies sudden consumption collapse</div>
            </div>
            <div style={{ background: '#f8fafc', padding: 10, borderRadius: 6, border: '1px solid #e2e8f0', fontSize: '0.78rem' }}>
              <div style={{ color: '#64748b' }}>Voltage vs Current Discordance</div>
              <div style={{ fontWeight: 700, color: '#0f172a', marginTop: 4 }}>Active V (&gt;200V) + 0 Load</div>
              <div style={{ color: '#94a3b8', fontSize: '0.72rem' }}>Signs of CT disconnect / bypass</div>
            </div>
            <div style={{ background: '#f8fafc', padding: 10, borderRadius: 6, border: '1px solid #e2e8f0', fontSize: '0.78rem' }}>
              <div style={{ color: '#64748b' }}>Zero-Load Streak Length</div>
              <div style={{ fontWeight: 700, color: '#0f172a', marginTop: 4 }}>Consecutive Inactive Days</div>
              <div style={{ color: '#94a3b8', fontSize: '0.72rem' }}>Flags prolonged abnormal shutdowns</div>
            </div>
          </div>
        </div>
      </div>

      {/* Flagged Anomalies Table */}
      <div className="card">
        <div className="card-title">
          <span>AI Anomaly Detection Results & Behavioral Explanations</span>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ position: 'relative' }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 10, color: '#94a3b8' }} />
              <input
                type="text"
                placeholder="Search consumer or meter ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="form-input"
                style={{ paddingLeft: 30, fontSize: '0.8rem', width: '240px', height: '32px' }}
              />
            </div>

            <select
              className="form-select"
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              style={{ fontSize: '0.8rem', height: '32px', width: '140px' }}
            >
              <option value="ALL">All Risk Levels</option>
              <option value="CRITICAL">Critical Only</option>
              <option value="HIGH">High Only</option>
              <option value="MEDIUM">Medium Only</option>
              <option value="LOW">Low Only</option>
            </select>
          </div>
        </div>

        <div className="table-container">
          <table className="data-table">
            <thead>
              <tr>
                <th>Consumer ID</th>
                <th>Meter ID</th>
                <th>Category</th>
                <th>Anomaly Score</th>
                <th>Calibrated Risk</th>
                <th>Reliability Qualification</th>
                <th>Primary Algorithmic Reason</th>
                <th>Investigation Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredResults.map((item) => (
                <tr key={item.consumer_id}>
                  <td className="code-cell">{item.consumer_id}</td>
                  <td className="code-cell" style={{ color: '#475569' }}>{item.meter_id}</td>
                  <td>{item.consumer_category}</td>
                  <td>
                    <span style={{
                      fontFamily: 'var(--font-mono)',
                      fontWeight: 800,
                      color: item.anomaly_score >= 0.7 ? '#dc2626' : item.anomaly_score >= 0.5 ? '#ea580c' : '#059669'
                    }}>
                      {item.anomaly_score.toFixed(3)}
                    </span>
                  </td>
                  <td>
                    <StatusBadge status={item.risk_level} />
                  </td>
                  <td>
                    <StatusBadge status={item.reliability_status} />
                  </td>
                  <td style={{ maxWidth: '320px', fontSize: '0.8rem', color: '#334155' }}>
                    {item.reasons?.[0] || 'Standard consumption profile'}
                  </td>
                  <td>
                    <button
                      className="btn-primary btn-sm"
                      onClick={() => {
                        setSelectedConsumer(item.consumer_id);
                        setActivePage('passport');
                      }}
                    >
                      <FileText size={13} />
                      Evidence Passport
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
