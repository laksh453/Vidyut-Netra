import React, { useState, useEffect } from 'react';
import {
  Settings,
  ShieldCheck,
  Cpu,
  Layers,
  Database,
  Save,
  CheckCircle2,
  Sliders,
  ExternalLink,
  Flame,
  Award,
  Info
} from 'lucide-react';
import { getSettings, updateSettings } from '../api';

export default function SettingsAboutPage() {
  const [settings, setSettings] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Form local state
  const [wObserved, setWObserved] = useState(1.0);
  const [wReconstructed, setWReconstructed] = useState(0.65);
  const [wInconsistent, setWInconsistent] = useState(2.0);
  const [wMissing, setWMissing] = useState(1.0);
  const [wDelayed, setWDelayed] = useState(0.3);

  const [sufficientThreshold, setSufficientThreshold] = useState(80.0);
  const [uncertainThreshold, setUncertainThreshold] = useState(60.0);

  const [tariffRate, setTariffRate] = useState(7.5);
  const [inspectionCost, setInspectionCost] = useState(1500);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const res = await getSettings();
      const s = res.data;
      setSettings(s);

      if (s.reliability_weights?.value) {
        const w = s.reliability_weights.value;
        setWObserved(w.w_observed || 1.0);
        setWReconstructed(w.w_reconstructed || 0.65);
        setWInconsistent(w.w_inconsistent || 2.0);
        setWMissing(w.w_missing || 1.0);
        setWDelayed(w.w_delayed || 0.3);
      }

      if (s.qualification_thresholds?.value) {
        const th = s.qualification_thresholds.value;
        setSufficientThreshold(th.sufficient || 80.0);
        setUncertainThreshold(th.uncertain || 60.0);
      }

      if (s.tariff_rate_inr?.value) {
        setTariffRate(parseFloat(s.tariff_rate_inr.value));
      }

      if (s.default_inspection_cost?.value) {
        setInspectionCost(parseFloat(s.default_inspection_cost.value));
      }
    } catch (err) {
      console.error('Error fetching settings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      const payload = {
        reliability_weights: {
          w_observed: parseFloat(wObserved),
          w_reconstructed: parseFloat(wReconstructed),
          w_inconsistent: parseFloat(wInconsistent),
          w_missing: parseFloat(wMissing),
          w_delayed: parseFloat(wDelayed)
        },
        qualification_thresholds: {
          sufficient: parseFloat(sufficientThreshold),
          uncertain: parseFloat(uncertainThreshold)
        },
        tariff_rate_inr: tariffRate.toString(),
        default_inspection_cost: inspectionCost.toString()
      };

      await updateSettings(payload);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3500);
    } catch (err) {
      alert('Error updating settings: ' + (err.response?.data?.error || err.message));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      {/* About Vidyut Netra Header Banner */}
      <div className="card" style={{ background: '#0f172a', color: '#ffffff', border: '1px solid #1e293b', padding: '28px' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: '0.74rem', fontWeight: 800, background: 'rgba(56, 189, 248, 0.15)', color: '#38bdf8', padding: '3px 8px', borderRadius: 4, letterSpacing: '0.08em', marginBottom: 12 }}>
          <Flame size={14} />
          TELANGANA INNOVATION STARTUP CHALLENGE 2026 (TISC 2026)
        </div>
        <h1 style={{ fontSize: '1.65rem', fontWeight: 900, marginBottom: 6, color: '#ffffff' }}>
          VIDYUT NETRA (విద్యుత్ నేత్ర)
        </h1>
        <p style={{ fontSize: '0.95rem', color: '#94a3b8', fontStyle: 'italic', marginBottom: 16 }}>
          "Intelligent Revenue Assurance for Smarter Electricity Distribution."
        </p>
        <p style={{ fontSize: '0.85rem', color: '#cbd5e1', lineHeight: 1.6, maxWidth: '960px' }}>
          Vidyut Netra is an AI-powered electricity distribution revenue-assurance platform designed for Distribution Companies (DISCOMs) 
          such as TSSPDCL and TSNPDCL. The platform addresses critical challenges including non-technical losses, meter tampering, telemetry packet loss, 
          and field resource misallocation by unifying <strong>Measurement Reliability Analysis</strong>, <strong>Unsupervised AI Anomaly Detection</strong>, 
          <strong>Explainable Evidence Passports</strong>, <strong>Reliability-Aware ROI Prioritization</strong>, and a <strong>Closed-Loop Inspection Feedback System</strong>.
        </p>
      </div>

      {/* 5 Core Research Pillars */}
      <div className="card">
        <div className="card-title">
          <span>Five Core Research Contributions & Innovations</span>
          <span style={{ fontSize: '0.78rem', color: '#64748b' }}>Technical Hackathon Evaluation</span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '14px' }}>
          <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: 4 }}>
              1. Measurement Reliability Engine
            </div>
            <div style={{ fontSize: '0.78rem', color: '#475569', lineHeight: 1.45 }}>
              Classifies smart-meter telemetry into 5 explicit states (Observed, Missing, Reconstructed, Inconsistent, Delayed) with mathematical provenance, ensuring data glitches are not mistaken for energy theft.
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: 4 }}>
              2. AI-Based Anomaly Detection
            </div>
            <div style={{ fontSize: '0.78rem', color: '#475569', lineHeight: 1.45 }}>
              Multivariate Isolation Forest ensemble extracting rolling trend shifts, voltage-current discordance, and zero streaks to flag suspicious deviations without making uncalibrated theft accusations.
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: 4 }}>
              3. Explainable Evidence Passports
            </div>
            <div style={{ fontSize: '0.78rem', color: '#475569', lineHeight: 1.45 }}>
              Audit-ready dossiers containing feature attribution, plausible benign explanations (e.g. rooftop solar, premise vacation), and standardized 6-point physical verification SOP checklists.
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: 4 }}>
              4. Reliability-Aware Prioritization
            </div>
            <div style={{ fontSize: '0.78rem', color: '#475569', lineHeight: 1.45 }}>
              Smart operational routing that sends high-confidence theft cases to revenue squads while redirecting unreliable sensor cases to hardware maintenance, optimizing squad ROI and route density.
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: 14, borderRadius: 8, border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: '0.82rem', fontWeight: 700, color: '#0369a1', marginBottom: 4 }}>
              5. Active Learning Feedback Loop
            </div>
            <div style={{ fontSize: '0.78rem', color: '#475569', lineHeight: 1.45 }}>
              Captures field outcomes (confirmed tampering, defective meter, legitimate solar drop) to retrain supervised Random Forest and Logistic Regression models, closing the gap between AI and reality.
            </div>
          </div>
        </div>
      </div>

      {/* Configurable System Parameters */}
      <div className="card">
        <div className="card-title">
          <span>Configurable Algorithmic Parameters & Tariff Settings</span>
          {saveSuccess && (
            <span style={{ fontSize: '0.8rem', color: '#059669', display: 'flex', alignItems: 'center', gap: 6, fontWeight: 600 }}>
              <CheckCircle2 size={16} />
              Settings saved successfully!
            </span>
          )}
        </div>

        <form onSubmit={handleSave}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '20px' }}>
            {/* Reliability Weights */}
            <div>
              <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', marginBottom: 12 }}>
                Measurement Reliability Score Weights:
              </h4>

              <div className="form-group">
                <label className="form-label">Observed Reading Weight (w_observed)</label>
                <input
                  type="number"
                  step="0.05"
                  className="form-input"
                  value={wObserved}
                  onChange={(e) => setWObserved(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Reconstructed Reading Weight (w_reconstructed)</label>
                <input
                  type="number"
                  step="0.05"
                  className="form-input"
                  value={wReconstructed}
                  onChange={(e) => setWReconstructed(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Inconsistent Reading Penalty Weight (w_inconsistent)</label>
                <input
                  type="number"
                  step="0.1"
                  className="form-input"
                  value={wInconsistent}
                  onChange={(e) => setWInconsistent(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Missing Reading Penalty Weight (w_missing)</label>
                <input
                  type="number"
                  step="0.1"
                  className="form-input"
                  value={wMissing}
                  onChange={(e) => setWMissing(e.target.value)}
                />
              </div>
            </div>

            {/* Thresholds & Economics */}
            <div>
              <h4 style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', marginBottom: 12 }}>
                Qualification Thresholds & Economic Assumptions:
              </h4>

              <div className="form-group">
                <label className="form-label">SUFFICIENT Qualification Cutoff (%)</label>
                <input
                  type="number"
                  step="1"
                  className="form-input"
                  value={sufficientThreshold}
                  onChange={(e) => setSufficientThreshold(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">UNCERTAIN Qualification Cutoff (%)</label>
                <input
                  type="number"
                  step="1"
                  className="form-input"
                  value={uncertainThreshold}
                  onChange={(e) => setUncertainThreshold(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Average Electricity Tariff (₹ / kWh)</label>
                <input
                  type="number"
                  step="0.1"
                  className="form-input"
                  value={tariffRate}
                  onChange={(e) => setTariffRate(e.target.value)}
                />
              </div>

              <div className="form-group">
                <label className="form-label">Estimated Squad Field Inspection Cost (₹ / Visit)</label>
                <input
                  type="number"
                  step="50"
                  className="form-input"
                  value={inspectionCost}
                  onChange={(e) => setInspectionCost(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button
              type="submit"
              className="btn-primary"
              disabled={saving}
            >
              <Save size={15} />
              {saving ? 'Updating Parameters...' : 'Save Configuration Changes'}
            </button>
          </div>
        </form>
      </div>

      {/* Ethical Charter Box */}
      <div className="card" style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: '0.88rem', fontWeight: 800, color: '#0f172a', marginBottom: 8 }}>
          <ShieldCheck size={18} color="#059669" />
          <span>Vidyut Netra Responsible AI & Ethical Revenue Assurance Charter</span>
        </div>
        <ul style={{ paddingLeft: 22, fontSize: '0.8rem', color: '#475569', lineHeight: 1.6 }}>
          <li><strong>Principle 1: Presumption of Legitimate Consumption.</strong> An unusual consumption pattern is mathematical variance, not criminal proof. Every finding requires human on-site physical verification.</li>
          <li><strong>Principle 2: Non-discrimination by Payment Status.</strong> Billing disputes, late payments, or commercial delinquency are billing administration issues and must NEVER be treated as evidence of physical electricity theft.</li>
          <li><strong>Principle 3: Full Audit Provenance.</strong> Original smart meter telemetry is immutable. Any imputed or reconstructed value must carry permanent lineage notes.</li>
          <li><strong>Principle 4: Respect for Benign Transition.</strong> The system proactively presents plausible alternative hypotheses (e.g. rooftop solar net metering, temporary vacancy) to prevent false harassment.</li>
        </ul>
      </div>
    </div>
  );
}
